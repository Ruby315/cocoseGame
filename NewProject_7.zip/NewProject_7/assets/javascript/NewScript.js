// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
      background:cc.Node,
      birdie:cc.Node,
      pipu1:cc.Sprite,
      pipu2:cc.Sprite,
      isIdle:true,
      speed:0,
      pipu:cc.Node,
      fail:cc.Node,
      apple:cc.Prefab,
      applePool:cc.NodePool,
      timeCount:0,
    },

   

     onLoad () {
     
      
        this.speed=0;
        
        this.isIdle=true;
        this.node.on("mousedown",this.onMouseDown,this);//绑定鼠标事件
        this.node.on("mouseup",this.onMouseUp,this);//绑定鼠标事件
        
        this.birdieNO=this.birdie.getComponent(cc.Sprite);//小鸟组件
         
        cc.tween(this.birdie)
      .to(0.8,{rotation:70})
     .start()

        var children=this.pipu.children;//得到管子的父节点
        children[0].x=0;//管子初始位置
        children[1].x=350;
        children[2].x=700;
        children[0].active=false;//管道不可见
        

        this.applePool=new cc.NodePool();
     },    

    start () {

    },
    update (dt) {
      this.timeCount+=1;
      if(this.timeCount%800==0){
        var speed=this.timeCount/1000;
            speed=-250+speed*0.2;
        var apple=this.newObject(this.applePool,this.apple);
        this.allAction(apple,-200,this.applePool,Math.random());         
       }
       
      this.speed-=0.05;//小鸟的速度更新       
      this.birdie.y+=this.speed;//小鸟上下移动

        this.background.x-=1;//背景移动
        if(this.background.x<=-1500){
           this.background.x=0;                 
        }
             
        var children=this.pipu.children;//得到所有障碍的父节点
        this.pipuMove(children[0]);//障碍物移动
        this.pipuMove(children[1]);   
        this.pipuMove(children[2]);      
        
        if(children[0].x<=-529){
          children[0].active=true;
        }
        
      
       
    },
    onMouseDown(){
      this.isIdle=false;
      this.speed=3;
       cc.tween(this.birdie)
   .to(0.3,{angle:70})
   .start()
    },
    onMouseUp(){
       this.isIdle=true;
       cc.tween(this.birdie)
       .delay(0.3)
     .to(0.8,{angle:-70})
    .start()
    },
   
   
   pipuMove(node){
      
      if(node.x-1<-530){
        node.x=530;
        var pipuY=Math.random()*50-25;
        node.y=pipuY;
      }
      node.x-=1.5;
   },
   newObject(objectPool,Prefab){
    var object = objectPool.get();
    if (object == null){
    object = cc.instantiate(Prefab);
    cc.log("create new apple");
   }
   object.parent=cc.find("Canvas");
   return object;
 },

allAction(object,speed,objectPool,y){
    y= y>=0.5 ? -30 : 30;
    object.position=cc.v2(525,y);     
    object.getComponent(cc.RigidBody).linearVelocity=cc.v2(speed,speed);
    objectPool=objectPool;
    object.getComponent(cc.RigidBody).scheduleOnce(function() {
      object.stopAllActions();
      objectPool.put(object);
      object.opacity=255;      
   }, 3);
  },
});
