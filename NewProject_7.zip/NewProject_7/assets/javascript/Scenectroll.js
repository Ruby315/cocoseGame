// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       startbutton:cc.Node,
       bird1:cc.Node,
       bird2:cc.Node,
    },

    // LIFE-CYCLE CALLBACKS:

     onLoad () {
        this.startbutton.on("mousedown",this.onMouseDown,this);
       
     },

    start () {

    },
   
    onMouseDown(){
        cc.director.loadScene("skinChoose");
    },
    // update (dt) {},
});
