// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       
    },

    

    onLoad () {},

    start () {

    },

    update (dt) {},
    onBeginContact: function (contact, selfCollider, otherCollider) {      
        if(otherCollider.node.group=="hidden"){
            var a= this.node.getComponent(cc.RigidBody).linearVelocity.y;
            this.node.getComponent(cc.RigidBody).linearVelocity=cc.v2(-200,-a);   
            console.log(this.node.getComponent(cc.RigidBody).linearVelocity.y);
        }
        
      
    
    },
});
