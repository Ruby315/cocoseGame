// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
      audioSource:cc.AudioSource,
      IsBlink:false,
      skin1:cc.SpriteFrame,
      skin2:cc.SpriteFrame,
    },

    
    onLoad () {
      cc.director.getCollisionManager().enabled=true;
      cc.director.getPhysicsManager().enabled = true;
      if(Global.skin==1){
        this.node.getComponent(cc.Sprite).spriteFrame=this.skin1;
      }else{
        this.node.getComponent(cc.Sprite).spriteFrame=this.skin2;
      }

    },

    start () {

    },

   update (dt) {

   },
   onCollisionEnter:function(other,self){
    
     var  numbernode = cc.find("Canvas/life/lifeNumber");//获取生命值文本信息
      var  string = numbernode.getComponent(cc.Label).string; 
      if(other.node.group=="block"){
        if(this.IsBlink==false){
          this.IsBlink=true;
          cc.tween(self.node) //角色触碰障碍物闪烁
          .blink(3,4)    
          .call( ()=>{
            this.IsBlink=false;           
          })
          .start()
          this.audioSource.play();//角色死亡音效
          numbernode.getComponent(cc.Label).string=String(Number(string)-1);
      }            
    }
      if(string<=1){
        this.node.active=false;//角色消失（死亡）   
        cc.director.loadScene("gameOver");
        
      }
         
   },
 
     onBeginContact: function (contact, selfCollider, otherCollider) {
      var  numbernode = cc.find("Canvas/life/lifeNumber");//获取生命值文本信息
      var  string = numbernode.getComponent(cc.Label).string; 
      
      if(otherCollider.node.group=="apple"){
          numbernode.getComponent(cc.Label).string=String(Number(string)+1);//生命值加一
          otherCollider.node.destroy();//摧毁节点`               
      }
      if(otherCollider.node.group=="floor"){
        this.node.active=false;//角色消失（死亡）   
        this.audioSource.play();//角色死亡音效
        cc.director.loadScene("gameOver");
      }
      
     
  
  },
});
