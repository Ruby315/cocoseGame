window.Global = {
      
    overGrade:0,
    skin:0,
};