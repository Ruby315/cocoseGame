// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        grade:cc.Label,
        count:0,
    },

   

    onLoad () {
        this.count=0;
        
    },

    start () {

    },

    update (dt) {
        this.count+=Math.ceil(dt);//向上取整(0.1--1)
        this.grade.string=this.count;
        Global.overGrade=this.count;
    },
});
