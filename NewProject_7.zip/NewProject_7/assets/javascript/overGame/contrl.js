// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        overGrade:cc.Label,
        skin1:cc.SpriteFrame,
        skin2:cc.SpriteFrame,
        animation:cc.Animation,
    },

  

    onLoad () {
        this.overGrade.string=Global.overGrade;
        this.animation=this.node.getComponent(cc.Animation);
        if(Global.skin==1){
           cc.find("Canvas/role2").active=false;
            
          }else{
            cc.find("Canvas/role").active=false;
          }
        
    },
    returnMenu(){
        cc.director.loadScene("SceneStart");
    },
    gameReplay(){       
        cc.director.loadScene("SceneEnter");
    },
    start () {

    },

    update (dt) {},
});
