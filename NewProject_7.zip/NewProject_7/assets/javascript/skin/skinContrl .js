
cc.Class({
    extends: cc.Component,

    properties: {
      
    },

   
    onLoad () {},

    start () {

    },
    skinChooseOne(){
        Global.skin=1;
       cc.director.loadScene("SceneEnter");
    },
    skinChooseTow(){
        Global.skin=2;
        cc.director.loadScene("SceneEnter");
     },
    ruleEnter(){
      cc.find("Canvas/rule").active=true;
    },
    ruleReturn(){
        cc.find("Canvas/rule").active=false;
      },
    returnMenu(){
      cc.director.loadScene("SceneStart");
    },
    update (dt) {},
});
