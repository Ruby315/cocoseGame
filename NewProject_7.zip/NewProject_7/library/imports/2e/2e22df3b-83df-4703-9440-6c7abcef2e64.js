"use strict";
cc._RF.push(module, '2e22d87g99HA5RAbHq87y5k', 'data');
// javascript/data.js

"use strict";

window.Global = {
  overGrade: 0,
  skin: 0
};

cc._RF.pop();