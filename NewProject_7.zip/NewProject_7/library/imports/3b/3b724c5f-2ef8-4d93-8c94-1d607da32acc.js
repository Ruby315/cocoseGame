"use strict";
cc._RF.push(module, '3b724xfLvhNk4yUHWB9oyrM', 'skinContrl ');
// javascript/skin/skinContrl .js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  start: function start() {},
  skinChooseOne: function skinChooseOne() {
    Global.skin = 1;
    cc.director.loadScene("SceneEnter");
  },
  skinChooseTow: function skinChooseTow() {
    Global.skin = 2;
    cc.director.loadScene("SceneEnter");
  },
  ruleEnter: function ruleEnter() {
    cc.find("Canvas/rule").active = true;
  },
  ruleReturn: function ruleReturn() {
    cc.find("Canvas/rule").active = false;
  },
  returnMenu: function returnMenu() {
    cc.director.loadScene("SceneStart");
  },
  update: function update(dt) {}
});

cc._RF.pop();