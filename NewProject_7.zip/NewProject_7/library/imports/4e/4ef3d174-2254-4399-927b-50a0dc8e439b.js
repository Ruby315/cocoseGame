"use strict";
cc._RF.push(module, '4ef3dF0IlRDmZJ7UKDcjkOb', 'gradeCtrl');
// javascript/gradeCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    grade: cc.Label,
    count: 0
  },
  onLoad: function onLoad() {
    this.count = 0;
  },
  start: function start() {},
  update: function update(dt) {
    this.count += Math.ceil(dt); //向上取整(0.1--1)

    this.grade.string = this.count;
    Global.overGrade = this.count;
  }
});

cc._RF.pop();