"use strict";
cc._RF.push(module, '622d8hc90xKfromshag65++', 'menuCtrl');
// javascript/menuCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  gamePause: function gamePause() {
    cc.find("Canvas/gamePause").active = true;
    cc.director.pause();
  },
  gameContinue: function gameContinue() {
    cc.find("Canvas/gamePause").active = false;
    cc.director.resume();
  },
  gameReplay: function gameReplay() {
    cc.director.resume();
    cc.director.loadScene("SceneEnter");
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();