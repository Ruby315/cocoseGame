"use strict";
cc._RF.push(module, 'b552aN0j8NNUKKLYjky3btk', 'contrl');
// javascript/overGame/contrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    overGrade: cc.Label,
    skin1: cc.SpriteFrame,
    skin2: cc.SpriteFrame,
    animation: cc.Animation
  },
  onLoad: function onLoad() {
    this.overGrade.string = Global.overGrade;
    this.animation = this.node.getComponent(cc.Animation);

    if (Global.skin == 1) {
      cc.find("Canvas/role2").active = false;
    } else {
      cc.find("Canvas/role").active = false;
    }
  },
  returnMenu: function returnMenu() {
    cc.director.loadScene("SceneStart");
  },
  gameReplay: function gameReplay() {
    cc.director.loadScene("SceneEnter");
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();