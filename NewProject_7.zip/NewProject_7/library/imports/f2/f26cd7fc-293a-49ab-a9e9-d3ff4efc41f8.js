"use strict";
cc._RF.push(module, 'f26cdf8KTpJq6np0/9O/EH4', 'Scenectroll');
// javascript/Scenectroll.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    startbutton: cc.Node,
    bird1: cc.Node,
    bird2: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.startbutton.on("mousedown", this.onMouseDown, this);
  },
  start: function start() {},
  onMouseDown: function onMouseDown() {
    cc.director.loadScene("skinChoose");
  } // update (dt) {},

});

cc._RF.pop();