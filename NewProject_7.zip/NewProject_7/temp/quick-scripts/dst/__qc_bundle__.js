
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/javascript/NewScript');
require('./assets/javascript/Scenectroll');
require('./assets/javascript/appleSelf');
require('./assets/javascript/collion');
require('./assets/javascript/data');
require('./assets/javascript/gradeCtrl');
require('./assets/javascript/menuCtrl');
require('./assets/javascript/overGame/contrl');
require('./assets/javascript/skin/skinContrl ');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/skin/skinContrl .js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3b724xfLvhNk4yUHWB9oyrM', 'skinContrl ');
// javascript/skin/skinContrl .js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  start: function start() {},
  skinChooseOne: function skinChooseOne() {
    Global.skin = 1;
    cc.director.loadScene("SceneEnter");
  },
  skinChooseTow: function skinChooseTow() {
    Global.skin = 2;
    cc.director.loadScene("SceneEnter");
  },
  ruleEnter: function ruleEnter() {
    cc.find("Canvas/rule").active = true;
  },
  ruleReturn: function ruleReturn() {
    cc.find("Canvas/rule").active = false;
  },
  returnMenu: function returnMenu() {
    cc.director.loadScene("SceneStart");
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcc2tpblxcc2tpbkNvbnRybCAuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJzdGFydCIsInNraW5DaG9vc2VPbmUiLCJHbG9iYWwiLCJza2luIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJza2luQ2hvb3NlVG93IiwicnVsZUVudGVyIiwiZmluZCIsImFjdGl2ZSIsInJ1bGVSZXR1cm4iLCJyZXR1cm5NZW51IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBUUxDLEVBQUFBLE1BUkssb0JBUUssQ0FBRSxDQVJQO0FBVUxDLEVBQUFBLEtBVkssbUJBVUksQ0FFUixDQVpJO0FBYUxDLEVBQUFBLGFBYkssMkJBYVU7QUFDWEMsSUFBQUEsTUFBTSxDQUFDQyxJQUFQLEdBQVksQ0FBWjtBQUNEUixJQUFBQSxFQUFFLENBQUNTLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixZQUF0QjtBQUNGLEdBaEJJO0FBaUJMQyxFQUFBQSxhQWpCSywyQkFpQlU7QUFDWEosSUFBQUEsTUFBTSxDQUFDQyxJQUFQLEdBQVksQ0FBWjtBQUNBUixJQUFBQSxFQUFFLENBQUNTLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixZQUF0QjtBQUNGLEdBcEJHO0FBcUJMRSxFQUFBQSxTQXJCSyx1QkFxQk07QUFDVFosSUFBQUEsRUFBRSxDQUFDYSxJQUFILENBQVEsYUFBUixFQUF1QkMsTUFBdkIsR0FBOEIsSUFBOUI7QUFDRCxHQXZCSTtBQXdCTEMsRUFBQUEsVUF4Qkssd0JBd0JPO0FBQ1JmLElBQUFBLEVBQUUsQ0FBQ2EsSUFBSCxDQUFRLGFBQVIsRUFBdUJDLE1BQXZCLEdBQThCLEtBQTlCO0FBQ0QsR0ExQkU7QUEyQkxFLEVBQUFBLFVBM0JLLHdCQTJCTztBQUNWaEIsSUFBQUEsRUFBRSxDQUFDUyxRQUFILENBQVlDLFNBQVosQ0FBc0IsWUFBdEI7QUFDRCxHQTdCSTtBQThCTE8sRUFBQUEsTUE5Qkssa0JBOEJHQyxFQTlCSCxFQThCTyxDQUFFO0FBOUJULENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICBcclxuICAgIH0sXHJcblxyXG4gICBcclxuICAgIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuICAgIHNraW5DaG9vc2VPbmUoKXtcclxuICAgICAgICBHbG9iYWwuc2tpbj0xO1xyXG4gICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiU2NlbmVFbnRlclwiKTtcclxuICAgIH0sXHJcbiAgICBza2luQ2hvb3NlVG93KCl7XHJcbiAgICAgICAgR2xvYmFsLnNraW49MjtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJTY2VuZUVudGVyXCIpO1xyXG4gICAgIH0sXHJcbiAgICBydWxlRW50ZXIoKXtcclxuICAgICAgY2MuZmluZChcIkNhbnZhcy9ydWxlXCIpLmFjdGl2ZT10cnVlO1xyXG4gICAgfSxcclxuICAgIHJ1bGVSZXR1cm4oKXtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3J1bGVcIikuYWN0aXZlPWZhbHNlO1xyXG4gICAgICB9LFxyXG4gICAgcmV0dXJuTWVudSgpe1xyXG4gICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJTY2VuZVN0YXJ0XCIpO1xyXG4gICAgfSxcclxuICAgIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/data.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2e22d87g99HA5RAbHq87y5k', 'data');
// javascript/data.js

"use strict";

window.Global = {
  overGrade: 0,
  skin: 0
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcZGF0YS5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJHbG9iYWwiLCJvdmVyR3JhZGUiLCJza2luIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsR0FBZ0I7QUFFWkMsRUFBQUEsU0FBUyxFQUFDLENBRkU7QUFHWkMsRUFBQUEsSUFBSSxFQUFDO0FBSE8sQ0FBaEIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIndpbmRvdy5HbG9iYWwgPSB7XHJcbiAgICAgIFxyXG4gICAgb3ZlckdyYWRlOjAsXHJcbiAgICBza2luOjAsXHJcbn07Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/overGame/contrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b552aN0j8NNUKKLYjky3btk', 'contrl');
// javascript/overGame/contrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    overGrade: cc.Label,
    skin1: cc.SpriteFrame,
    skin2: cc.SpriteFrame,
    animation: cc.Animation
  },
  onLoad: function onLoad() {
    this.overGrade.string = Global.overGrade;
    this.animation = this.node.getComponent(cc.Animation);

    if (Global.skin == 1) {
      cc.find("Canvas/role2").active = false;
    } else {
      cc.find("Canvas/role").active = false;
    }
  },
  returnMenu: function returnMenu() {
    cc.director.loadScene("SceneStart");
  },
  gameReplay: function gameReplay() {
    cc.director.loadScene("SceneEnter");
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcb3ZlckdhbWVcXGNvbnRybC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm92ZXJHcmFkZSIsIkxhYmVsIiwic2tpbjEiLCJTcHJpdGVGcmFtZSIsInNraW4yIiwiYW5pbWF0aW9uIiwiQW5pbWF0aW9uIiwib25Mb2FkIiwic3RyaW5nIiwiR2xvYmFsIiwibm9kZSIsImdldENvbXBvbmVudCIsInNraW4iLCJmaW5kIiwiYWN0aXZlIiwicmV0dXJuTWVudSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwiZ2FtZVJlcGxheSIsInN0YXJ0IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxTQUFTLEVBQUNKLEVBQUUsQ0FBQ0ssS0FETDtBQUVSQyxJQUFBQSxLQUFLLEVBQUNOLEVBQUUsQ0FBQ08sV0FGRDtBQUdSQyxJQUFBQSxLQUFLLEVBQUNSLEVBQUUsQ0FBQ08sV0FIRDtBQUlSRSxJQUFBQSxTQUFTLEVBQUNULEVBQUUsQ0FBQ1U7QUFKTCxHQUhQO0FBWUxDLEVBQUFBLE1BWkssb0JBWUs7QUFDTixTQUFLUCxTQUFMLENBQWVRLE1BQWYsR0FBc0JDLE1BQU0sQ0FBQ1QsU0FBN0I7QUFDQSxTQUFLSyxTQUFMLEdBQWUsS0FBS0ssSUFBTCxDQUFVQyxZQUFWLENBQXVCZixFQUFFLENBQUNVLFNBQTFCLENBQWY7O0FBQ0EsUUFBR0csTUFBTSxDQUFDRyxJQUFQLElBQWEsQ0FBaEIsRUFBa0I7QUFDZmhCLE1BQUFBLEVBQUUsQ0FBQ2lCLElBQUgsQ0FBUSxjQUFSLEVBQXdCQyxNQUF4QixHQUErQixLQUEvQjtBQUVBLEtBSEgsTUFHTztBQUNIbEIsTUFBQUEsRUFBRSxDQUFDaUIsSUFBSCxDQUFRLGFBQVIsRUFBdUJDLE1BQXZCLEdBQThCLEtBQTlCO0FBQ0Q7QUFFTixHQXRCSTtBQXVCTEMsRUFBQUEsVUF2Qkssd0JBdUJPO0FBQ1JuQixJQUFBQSxFQUFFLENBQUNvQixRQUFILENBQVlDLFNBQVosQ0FBc0IsWUFBdEI7QUFDSCxHQXpCSTtBQTBCTEMsRUFBQUEsVUExQkssd0JBMEJPO0FBQ1J0QixJQUFBQSxFQUFFLENBQUNvQixRQUFILENBQVlDLFNBQVosQ0FBc0IsWUFBdEI7QUFDSCxHQTVCSTtBQTZCTEUsRUFBQUEsS0E3QkssbUJBNkJJLENBRVIsQ0EvQkk7QUFpQ0xDLEVBQUFBLE1BakNLLGtCQWlDR0MsRUFqQ0gsRUFpQ08sQ0FBRTtBQWpDVCxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgb3ZlckdyYWRlOmNjLkxhYmVsLFxyXG4gICAgICAgIHNraW4xOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIHNraW4yOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIGFuaW1hdGlvbjpjYy5BbmltYXRpb24sXHJcbiAgICB9LFxyXG5cclxuICBcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMub3ZlckdyYWRlLnN0cmluZz1HbG9iYWwub3ZlckdyYWRlO1xyXG4gICAgICAgIHRoaXMuYW5pbWF0aW9uPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcclxuICAgICAgICBpZihHbG9iYWwuc2tpbj09MSl7XHJcbiAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9yb2xlMlwiKS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcm9sZVwiKS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgcmV0dXJuTWVudSgpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIlNjZW5lU3RhcnRcIik7XHJcbiAgICB9LFxyXG4gICAgZ2FtZVJlcGxheSgpeyAgICAgICBcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJTY2VuZUVudGVyXCIpO1xyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/collion.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f5b8f33mLRBr4KuxCAjyyJK', 'collion');
// javascript/collion.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    audioSource: cc.AudioSource,
    IsBlink: false,
    skin1: cc.SpriteFrame,
    skin2: cc.SpriteFrame
  },
  onLoad: function onLoad() {
    cc.director.getCollisionManager().enabled = true;
    cc.director.getPhysicsManager().enabled = true;

    if (Global.skin == 1) {
      this.node.getComponent(cc.Sprite).spriteFrame = this.skin1;
    } else {
      this.node.getComponent(cc.Sprite).spriteFrame = this.skin2;
    }
  },
  start: function start() {},
  update: function update(dt) {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    var _this = this;

    var numbernode = cc.find("Canvas/life/lifeNumber"); //获取生命值文本信息

    var string = numbernode.getComponent(cc.Label).string;

    if (other.node.group == "block") {
      if (this.IsBlink == false) {
        this.IsBlink = true;
        cc.tween(self.node) //角色触碰障碍物闪烁
        .blink(3, 4).call(function () {
          _this.IsBlink = false;
        }).start();
        this.audioSource.play(); //角色死亡音效

        numbernode.getComponent(cc.Label).string = String(Number(string) - 1);
      }
    }

    if (string <= 1) {
      this.node.active = false; //角色消失（死亡）   

      cc.director.loadScene("gameOver");
    }
  },
  onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
    var numbernode = cc.find("Canvas/life/lifeNumber"); //获取生命值文本信息

    var string = numbernode.getComponent(cc.Label).string;

    if (otherCollider.node.group == "apple") {
      numbernode.getComponent(cc.Label).string = String(Number(string) + 1); //生命值加一

      otherCollider.node.destroy(); //摧毁节点`               
    }

    if (otherCollider.node.group == "floor") {
      this.node.active = false; //角色消失（死亡）   

      this.audioSource.play(); //角色死亡音效

      cc.director.loadScene("gameOver");
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcY29sbGlvbi5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImF1ZGlvU291cmNlIiwiQXVkaW9Tb3VyY2UiLCJJc0JsaW5rIiwic2tpbjEiLCJTcHJpdGVGcmFtZSIsInNraW4yIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJnZXRDb2xsaXNpb25NYW5hZ2VyIiwiZW5hYmxlZCIsImdldFBoeXNpY3NNYW5hZ2VyIiwiR2xvYmFsIiwic2tpbiIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsInN0YXJ0IiwidXBkYXRlIiwiZHQiLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwibnVtYmVybm9kZSIsImZpbmQiLCJzdHJpbmciLCJMYWJlbCIsImdyb3VwIiwidHdlZW4iLCJibGluayIsImNhbGwiLCJwbGF5IiwiU3RyaW5nIiwiTnVtYmVyIiwiYWN0aXZlIiwibG9hZFNjZW5lIiwib25CZWdpbkNvbnRhY3QiLCJjb250YWN0Iiwic2VsZkNvbGxpZGVyIiwib3RoZXJDb2xsaWRlciIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNWQyxJQUFBQSxXQUFXLEVBQUNKLEVBQUUsQ0FBQ0ssV0FETDtBQUVWQyxJQUFBQSxPQUFPLEVBQUMsS0FGRTtBQUdWQyxJQUFBQSxLQUFLLEVBQUNQLEVBQUUsQ0FBQ1EsV0FIQztBQUlWQyxJQUFBQSxLQUFLLEVBQUNULEVBQUUsQ0FBQ1E7QUFKQyxHQUhQO0FBV0xFLEVBQUFBLE1BWEssb0JBV0s7QUFDUlYsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLG1CQUFaLEdBQWtDQyxPQUFsQyxHQUEwQyxJQUExQztBQUNBYixJQUFBQSxFQUFFLENBQUNXLFFBQUgsQ0FBWUcsaUJBQVosR0FBZ0NELE9BQWhDLEdBQTBDLElBQTFDOztBQUNBLFFBQUdFLE1BQU0sQ0FBQ0MsSUFBUCxJQUFhLENBQWhCLEVBQWtCO0FBQ2hCLFdBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QmxCLEVBQUUsQ0FBQ21CLE1BQTFCLEVBQWtDQyxXQUFsQyxHQUE4QyxLQUFLYixLQUFuRDtBQUNELEtBRkQsTUFFSztBQUNILFdBQUtVLElBQUwsQ0FBVUMsWUFBVixDQUF1QmxCLEVBQUUsQ0FBQ21CLE1BQTFCLEVBQWtDQyxXQUFsQyxHQUE4QyxLQUFLWCxLQUFuRDtBQUNEO0FBRUYsR0FwQkk7QUFzQkxZLEVBQUFBLEtBdEJLLG1CQXNCSSxDQUVSLENBeEJJO0FBMEJOQyxFQUFBQSxNQTFCTSxrQkEwQkVDLEVBMUJGLEVBMEJNLENBRVgsQ0E1Qks7QUE2Qk5DLEVBQUFBLGdCQUFnQixFQUFDLDBCQUFTQyxLQUFULEVBQWVDLElBQWYsRUFBb0I7QUFBQTs7QUFFbkMsUUFBS0MsVUFBVSxHQUFHM0IsRUFBRSxDQUFDNEIsSUFBSCxDQUFRLHdCQUFSLENBQWxCLENBRm1DLENBRWlCOztBQUNuRCxRQUFLQyxNQUFNLEdBQUdGLFVBQVUsQ0FBQ1QsWUFBWCxDQUF3QmxCLEVBQUUsQ0FBQzhCLEtBQTNCLEVBQWtDRCxNQUFoRDs7QUFDQSxRQUFHSixLQUFLLENBQUNSLElBQU4sQ0FBV2MsS0FBWCxJQUFrQixPQUFyQixFQUE2QjtBQUMzQixVQUFHLEtBQUt6QixPQUFMLElBQWMsS0FBakIsRUFBdUI7QUFDckIsYUFBS0EsT0FBTCxHQUFhLElBQWI7QUFDQU4sUUFBQUEsRUFBRSxDQUFDZ0MsS0FBSCxDQUFTTixJQUFJLENBQUNULElBQWQsRUFBb0I7QUFBcEIsU0FDQ2dCLEtBREQsQ0FDTyxDQURQLEVBQ1MsQ0FEVCxFQUVDQyxJQUZELENBRU8sWUFBSTtBQUNULFVBQUEsS0FBSSxDQUFDNUIsT0FBTCxHQUFhLEtBQWI7QUFDRCxTQUpELEVBS0NlLEtBTEQ7QUFNQSxhQUFLakIsV0FBTCxDQUFpQitCLElBQWpCLEdBUnFCLENBUUc7O0FBQ3hCUixRQUFBQSxVQUFVLENBQUNULFlBQVgsQ0FBd0JsQixFQUFFLENBQUM4QixLQUEzQixFQUFrQ0QsTUFBbEMsR0FBeUNPLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDUixNQUFELENBQU4sR0FBZSxDQUFoQixDQUEvQztBQUNIO0FBQ0Y7O0FBQ0MsUUFBR0EsTUFBTSxJQUFFLENBQVgsRUFBYTtBQUNYLFdBQUtaLElBQUwsQ0FBVXFCLE1BQVYsR0FBaUIsS0FBakIsQ0FEVyxDQUNZOztBQUN2QnRDLE1BQUFBLEVBQUUsQ0FBQ1csUUFBSCxDQUFZNEIsU0FBWixDQUFzQixVQUF0QjtBQUVEO0FBRUgsR0FwREs7QUFzREpDLEVBQUFBLGNBQWMsRUFBRSx3QkFBVUMsT0FBVixFQUFtQkMsWUFBbkIsRUFBaUNDLGFBQWpDLEVBQWdEO0FBQy9ELFFBQUtoQixVQUFVLEdBQUczQixFQUFFLENBQUM0QixJQUFILENBQVEsd0JBQVIsQ0FBbEIsQ0FEK0QsQ0FDWDs7QUFDcEQsUUFBS0MsTUFBTSxHQUFHRixVQUFVLENBQUNULFlBQVgsQ0FBd0JsQixFQUFFLENBQUM4QixLQUEzQixFQUFrQ0QsTUFBaEQ7O0FBRUEsUUFBR2MsYUFBYSxDQUFDMUIsSUFBZCxDQUFtQmMsS0FBbkIsSUFBMEIsT0FBN0IsRUFBcUM7QUFDakNKLE1BQUFBLFVBQVUsQ0FBQ1QsWUFBWCxDQUF3QmxCLEVBQUUsQ0FBQzhCLEtBQTNCLEVBQWtDRCxNQUFsQyxHQUF5Q08sTUFBTSxDQUFDQyxNQUFNLENBQUNSLE1BQUQsQ0FBTixHQUFlLENBQWhCLENBQS9DLENBRGlDLENBQ2lDOztBQUNsRWMsTUFBQUEsYUFBYSxDQUFDMUIsSUFBZCxDQUFtQjJCLE9BQW5CLEdBRmlDLENBRUo7QUFDaEM7O0FBQ0QsUUFBR0QsYUFBYSxDQUFDMUIsSUFBZCxDQUFtQmMsS0FBbkIsSUFBMEIsT0FBN0IsRUFBcUM7QUFDbkMsV0FBS2QsSUFBTCxDQUFVcUIsTUFBVixHQUFpQixLQUFqQixDQURtQyxDQUNaOztBQUN2QixXQUFLbEMsV0FBTCxDQUFpQitCLElBQWpCLEdBRm1DLENBRVg7O0FBQ3hCbkMsTUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVk0QixTQUFaLENBQXNCLFVBQXRCO0FBQ0Q7QUFJSjtBQXRFTSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgIGF1ZGlvU291cmNlOmNjLkF1ZGlvU291cmNlLFxyXG4gICAgICBJc0JsaW5rOmZhbHNlLFxyXG4gICAgICBza2luMTpjYy5TcHJpdGVGcmFtZSxcclxuICAgICAgc2tpbjI6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICB9LFxyXG5cclxuICAgIFxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpLmVuYWJsZWQ9dHJ1ZTtcclxuICAgICAgY2MuZGlyZWN0b3IuZ2V0UGh5c2ljc01hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcclxuICAgICAgaWYoR2xvYmFsLnNraW49PTEpe1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT10aGlzLnNraW4xO1xyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9dGhpcy5za2luMjtcclxuICAgICAgfVxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICB1cGRhdGUgKGR0KSB7XHJcblxyXG4gICB9LFxyXG4gICBvbkNvbGxpc2lvbkVudGVyOmZ1bmN0aW9uKG90aGVyLHNlbGYpe1xyXG4gICAgXHJcbiAgICAgdmFyICBudW1iZXJub2RlID0gY2MuZmluZChcIkNhbnZhcy9saWZlL2xpZmVOdW1iZXJcIik7Ly/ojrflj5bnlJ/lkb3lgLzmlofmnKzkv6Hmga9cclxuICAgICAgdmFyICBzdHJpbmcgPSBudW1iZXJub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nOyBcclxuICAgICAgaWYob3RoZXIubm9kZS5ncm91cD09XCJibG9ja1wiKXtcclxuICAgICAgICBpZih0aGlzLklzQmxpbms9PWZhbHNlKXtcclxuICAgICAgICAgIHRoaXMuSXNCbGluaz10cnVlO1xyXG4gICAgICAgICAgY2MudHdlZW4oc2VsZi5ub2RlKSAvL+inkuiJsuinpueisOmanOeijeeJqemXqueDgVxyXG4gICAgICAgICAgLmJsaW5rKDMsNCkgICAgXHJcbiAgICAgICAgICAuY2FsbCggKCk9PntcclxuICAgICAgICAgICAgdGhpcy5Jc0JsaW5rPWZhbHNlOyAgICAgICAgICAgXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLnN0YXJ0KClcclxuICAgICAgICAgIHRoaXMuYXVkaW9Tb3VyY2UucGxheSgpOy8v6KeS6Imy5q275Lqh6Z+z5pWIXHJcbiAgICAgICAgICBudW1iZXJub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVN0cmluZyhOdW1iZXIoc3RyaW5nKS0xKTtcclxuICAgICAgfSAgICAgICAgICAgIFxyXG4gICAgfVxyXG4gICAgICBpZihzdHJpbmc8PTEpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmU9ZmFsc2U7Ly/op5LoibLmtojlpLHvvIjmrbvkuqHvvIkgICBcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJnYW1lT3ZlclwiKTtcclxuICAgICAgICBcclxuICAgICAgfVxyXG4gICAgICAgICBcclxuICAgfSxcclxuIFxyXG4gICAgIG9uQmVnaW5Db250YWN0OiBmdW5jdGlvbiAoY29udGFjdCwgc2VsZkNvbGxpZGVyLCBvdGhlckNvbGxpZGVyKSB7XHJcbiAgICAgIHZhciAgbnVtYmVybm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvbGlmZS9saWZlTnVtYmVyXCIpOy8v6I635Y+W55Sf5ZG95YC85paH5pys5L+h5oGvXHJcbiAgICAgIHZhciAgc3RyaW5nID0gbnVtYmVybm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZzsgXHJcbiAgICAgIFxyXG4gICAgICBpZihvdGhlckNvbGxpZGVyLm5vZGUuZ3JvdXA9PVwiYXBwbGVcIil7XHJcbiAgICAgICAgICBudW1iZXJub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVN0cmluZyhOdW1iZXIoc3RyaW5nKSsxKTsvL+eUn+WRveWAvOWKoOS4gFxyXG4gICAgICAgICAgb3RoZXJDb2xsaWRlci5ub2RlLmRlc3Ryb3koKTsvL+aRp+avgeiKgueCuWAgICAgICAgICAgICAgICBcclxuICAgICAgfVxyXG4gICAgICBpZihvdGhlckNvbGxpZGVyLm5vZGUuZ3JvdXA9PVwiZmxvb3JcIil7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZT1mYWxzZTsvL+inkuiJsua2iOWkse+8iOatu+S6oe+8iSAgIFxyXG4gICAgICAgIHRoaXMuYXVkaW9Tb3VyY2UucGxheSgpOy8v6KeS6Imy5q275Lqh6Z+z5pWIXHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiZ2FtZU92ZXJcIik7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgXHJcbiAgXHJcbiAgfSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/menuCtrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '622d8hc90xKfromshag65++', 'menuCtrl');
// javascript/menuCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  gamePause: function gamePause() {
    cc.find("Canvas/gamePause").active = true;
    cc.director.pause();
  },
  gameContinue: function gameContinue() {
    cc.find("Canvas/gamePause").active = false;
    cc.director.resume();
  },
  gameReplay: function gameReplay() {
    cc.director.resume();
    cc.director.loadScene("SceneEnter");
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcbWVudUN0cmwuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJnYW1lUGF1c2UiLCJmaW5kIiwiYWN0aXZlIiwiZGlyZWN0b3IiLCJwYXVzZSIsImdhbWVDb250aW51ZSIsInJlc3VtZSIsImdhbWVSZXBsYXkiLCJsb2FkU2NlbmUiLCJzdGFydCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQVNMQyxFQUFBQSxNQVRLLG9CQVNLLENBQUUsQ0FUUDtBQVVMQyxFQUFBQSxTQVZLLHVCQVVNO0FBQ1BMLElBQUFBLEVBQUUsQ0FBQ00sSUFBSCxDQUFRLGtCQUFSLEVBQTRCQyxNQUE1QixHQUFtQyxJQUFuQztBQUNBUCxJQUFBQSxFQUFFLENBQUNRLFFBQUgsQ0FBWUMsS0FBWjtBQUNILEdBYkk7QUFjTEMsRUFBQUEsWUFkSywwQkFjUztBQUNWVixJQUFBQSxFQUFFLENBQUNNLElBQUgsQ0FBUSxrQkFBUixFQUE0QkMsTUFBNUIsR0FBbUMsS0FBbkM7QUFDQVAsSUFBQUEsRUFBRSxDQUFDUSxRQUFILENBQVlHLE1BQVo7QUFFSCxHQWxCSTtBQW1CTEMsRUFBQUEsVUFuQkssd0JBbUJPO0FBQ1JaLElBQUFBLEVBQUUsQ0FBQ1EsUUFBSCxDQUFZRyxNQUFaO0FBQ0FYLElBQUFBLEVBQUUsQ0FBQ1EsUUFBSCxDQUFZSyxTQUFaLENBQXNCLFlBQXRCO0FBQ0gsR0F0Qkk7QUF1QkxDLEVBQUFBLEtBdkJLLG1CQXVCSSxDQUVSLENBekJJO0FBMkJMQyxFQUFBQSxNQTNCSyxrQkEyQkdDLEVBM0JILEVBMkJPLENBQUU7QUEzQlQsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICBcclxuICAgIH0sXHJcblxyXG4gICBcclxuXHJcbiAgICBvbkxvYWQgKCkge30sXHJcbiAgICBnYW1lUGF1c2UoKXtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2dhbWVQYXVzZVwiKS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5wYXVzZSgpO1xyXG4gICAgfSxcclxuICAgIGdhbWVDb250aW51ZSgpe1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvZ2FtZVBhdXNlXCIpLmFjdGl2ZT1mYWxzZTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5yZXN1bWUoKTtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBnYW1lUmVwbGF5KCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IucmVzdW1lKCk7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiU2NlbmVFbnRlclwiKTtcclxuICAgIH0sXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcblxyXG4gICAgIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/appleSelf.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd070d3FL2dMEIFSAYI534TA', 'appleSelf');
// javascript/appleSelf.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  start: function start() {},
  update: function update(dt) {},
  onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
    if (otherCollider.node.group == "hidden") {
      var a = this.node.getComponent(cc.RigidBody).linearVelocity.y;
      this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(-200, -a);
      console.log(this.node.getComponent(cc.RigidBody).linearVelocity.y);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcYXBwbGVTZWxmLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInNlbGZDb2xsaWRlciIsIm90aGVyQ29sbGlkZXIiLCJub2RlIiwiZ3JvdXAiLCJhIiwiZ2V0Q29tcG9uZW50IiwiUmlnaWRCb2R5IiwibGluZWFyVmVsb2NpdHkiLCJ5IiwidjIiLCJjb25zb2xlIiwibG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQVNMQyxFQUFBQSxNQVRLLG9CQVNLLENBQUUsQ0FUUDtBQVdMQyxFQUFBQSxLQVhLLG1CQVdJLENBRVIsQ0FiSTtBQWVMQyxFQUFBQSxNQWZLLGtCQWVHQyxFQWZILEVBZU8sQ0FBRSxDQWZUO0FBZ0JMQyxFQUFBQSxjQUFjLEVBQUUsd0JBQVVDLE9BQVYsRUFBbUJDLFlBQW5CLEVBQWlDQyxhQUFqQyxFQUFnRDtBQUM1RCxRQUFHQSxhQUFhLENBQUNDLElBQWQsQ0FBbUJDLEtBQW5CLElBQTBCLFFBQTdCLEVBQXNDO0FBQ2xDLFVBQUlDLENBQUMsR0FBRSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJmLEVBQUUsQ0FBQ2dCLFNBQTFCLEVBQXFDQyxjQUFyQyxDQUFvREMsQ0FBM0Q7QUFDQSxXQUFLTixJQUFMLENBQVVHLFlBQVYsQ0FBdUJmLEVBQUUsQ0FBQ2dCLFNBQTFCLEVBQXFDQyxjQUFyQyxHQUFvRGpCLEVBQUUsQ0FBQ21CLEVBQUgsQ0FBTSxDQUFDLEdBQVAsRUFBVyxDQUFDTCxDQUFaLENBQXBEO0FBQ0FNLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQUtULElBQUwsQ0FBVUcsWUFBVixDQUF1QmYsRUFBRSxDQUFDZ0IsU0FBMUIsRUFBcUNDLGNBQXJDLENBQW9EQyxDQUFoRTtBQUNIO0FBSUo7QUF6QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIFxyXG5cclxuICAgIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7fSxcclxuICAgIG9uQmVnaW5Db250YWN0OiBmdW5jdGlvbiAoY29udGFjdCwgc2VsZkNvbGxpZGVyLCBvdGhlckNvbGxpZGVyKSB7ICAgICAgXHJcbiAgICAgICAgaWYob3RoZXJDb2xsaWRlci5ub2RlLmdyb3VwPT1cImhpZGRlblwiKXtcclxuICAgICAgICAgICAgdmFyIGE9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS5saW5lYXJWZWxvY2l0eS55O1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHk9Y2MudjIoLTIwMCwtYSk7ICAgXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS5saW5lYXJWZWxvY2l0eS55KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIFxyXG4gICAgXHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/NewScript.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '758faw5gzZK05j8EpwP4UBk', 'NewScript');
// javascript/NewScript.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    background: cc.Node,
    birdie: cc.Node,
    pipu1: cc.Sprite,
    pipu2: cc.Sprite,
    isIdle: true,
    speed: 0,
    pipu: cc.Node,
    fail: cc.Node,
    apple: cc.Prefab,
    applePool: cc.NodePool,
    timeCount: 0
  },
  onLoad: function onLoad() {
    this.speed = 0;
    this.isIdle = true;
    this.node.on("mousedown", this.onMouseDown, this); //绑定鼠标事件

    this.node.on("mouseup", this.onMouseUp, this); //绑定鼠标事件

    this.birdieNO = this.birdie.getComponent(cc.Sprite); //小鸟组件

    cc.tween(this.birdie).to(0.8, {
      rotation: 70
    }).start();
    var children = this.pipu.children; //得到管子的父节点

    children[0].x = 0; //管子初始位置

    children[1].x = 350;
    children[2].x = 700;
    children[0].active = false; //管道不可见

    this.applePool = new cc.NodePool();
  },
  start: function start() {},
  update: function update(dt) {
    this.timeCount += 1;

    if (this.timeCount % 800 == 0) {
      var speed = this.timeCount / 1000;
      speed = -250 + speed * 0.2;
      var apple = this.newObject(this.applePool, this.apple);
      this.allAction(apple, -200, this.applePool, Math.random());
    }

    this.speed -= 0.05; //小鸟的速度更新       

    this.birdie.y += this.speed; //小鸟上下移动

    this.background.x -= 1; //背景移动

    if (this.background.x <= -1500) {
      this.background.x = 0;
    }

    var children = this.pipu.children; //得到所有障碍的父节点

    this.pipuMove(children[0]); //障碍物移动

    this.pipuMove(children[1]);
    this.pipuMove(children[2]);

    if (children[0].x <= -529) {
      children[0].active = true;
    }
  },
  onMouseDown: function onMouseDown() {
    this.isIdle = false;
    this.speed = 3;
    cc.tween(this.birdie).to(0.3, {
      angle: 70
    }).start();
  },
  onMouseUp: function onMouseUp() {
    this.isIdle = true;
    cc.tween(this.birdie).delay(0.3).to(0.8, {
      angle: -70
    }).start();
  },
  pipuMove: function pipuMove(node) {
    if (node.x - 1 < -530) {
      node.x = 530;
      var pipuY = Math.random() * 50 - 25;
      node.y = pipuY;
    }

    node.x -= 1.5;
  },
  newObject: function newObject(objectPool, Prefab) {
    var object = objectPool.get();

    if (object == null) {
      object = cc.instantiate(Prefab);
      cc.log("create new apple");
    }

    object.parent = cc.find("Canvas");
    return object;
  },
  allAction: function allAction(object, speed, objectPool, y) {
    y = y >= 0.5 ? -30 : 30;
    object.position = cc.v2(525, y);
    object.getComponent(cc.RigidBody).linearVelocity = cc.v2(speed, speed);
    objectPool = objectPool;
    object.getComponent(cc.RigidBody).scheduleOnce(function () {
      object.stopAllActions();
      objectPool.put(object);
      object.opacity = 255;
    }, 3);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcTmV3U2NyaXB0LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYmFja2dyb3VuZCIsIk5vZGUiLCJiaXJkaWUiLCJwaXB1MSIsIlNwcml0ZSIsInBpcHUyIiwiaXNJZGxlIiwic3BlZWQiLCJwaXB1IiwiZmFpbCIsImFwcGxlIiwiUHJlZmFiIiwiYXBwbGVQb29sIiwiTm9kZVBvb2wiLCJ0aW1lQ291bnQiLCJvbkxvYWQiLCJub2RlIiwib24iLCJvbk1vdXNlRG93biIsIm9uTW91c2VVcCIsImJpcmRpZU5PIiwiZ2V0Q29tcG9uZW50IiwidHdlZW4iLCJ0byIsInJvdGF0aW9uIiwic3RhcnQiLCJjaGlsZHJlbiIsIngiLCJhY3RpdmUiLCJ1cGRhdGUiLCJkdCIsIm5ld09iamVjdCIsImFsbEFjdGlvbiIsIk1hdGgiLCJyYW5kb20iLCJ5IiwicGlwdU1vdmUiLCJhbmdsZSIsImRlbGF5IiwicGlwdVkiLCJvYmplY3RQb29sIiwib2JqZWN0IiwiZ2V0IiwiaW5zdGFudGlhdGUiLCJsb2ciLCJwYXJlbnQiLCJmaW5kIiwicG9zaXRpb24iLCJ2MiIsIlJpZ2lkQm9keSIsImxpbmVhclZlbG9jaXR5Iiwic2NoZWR1bGVPbmNlIiwic3RvcEFsbEFjdGlvbnMiLCJwdXQiLCJvcGFjaXR5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDVkMsSUFBQUEsVUFBVSxFQUFDSixFQUFFLENBQUNLLElBREo7QUFFVkMsSUFBQUEsTUFBTSxFQUFDTixFQUFFLENBQUNLLElBRkE7QUFHVkUsSUFBQUEsS0FBSyxFQUFDUCxFQUFFLENBQUNRLE1BSEM7QUFJVkMsSUFBQUEsS0FBSyxFQUFDVCxFQUFFLENBQUNRLE1BSkM7QUFLVkUsSUFBQUEsTUFBTSxFQUFDLElBTEc7QUFNVkMsSUFBQUEsS0FBSyxFQUFDLENBTkk7QUFPVkMsSUFBQUEsSUFBSSxFQUFDWixFQUFFLENBQUNLLElBUEU7QUFRVlEsSUFBQUEsSUFBSSxFQUFDYixFQUFFLENBQUNLLElBUkU7QUFTVlMsSUFBQUEsS0FBSyxFQUFDZCxFQUFFLENBQUNlLE1BVEM7QUFVVkMsSUFBQUEsU0FBUyxFQUFDaEIsRUFBRSxDQUFDaUIsUUFWSDtBQVdWQyxJQUFBQSxTQUFTLEVBQUM7QUFYQSxHQUhQO0FBbUJKQyxFQUFBQSxNQW5CSSxvQkFtQk07QUFHUCxTQUFLUixLQUFMLEdBQVcsQ0FBWDtBQUVBLFNBQUtELE1BQUwsR0FBWSxJQUFaO0FBQ0EsU0FBS1UsSUFBTCxDQUFVQyxFQUFWLENBQWEsV0FBYixFQUF5QixLQUFLQyxXQUE5QixFQUEwQyxJQUExQyxFQU5PLENBTXlDOztBQUNoRCxTQUFLRixJQUFMLENBQVVDLEVBQVYsQ0FBYSxTQUFiLEVBQXVCLEtBQUtFLFNBQTVCLEVBQXNDLElBQXRDLEVBUE8sQ0FPcUM7O0FBRTVDLFNBQUtDLFFBQUwsR0FBYyxLQUFLbEIsTUFBTCxDQUFZbUIsWUFBWixDQUF5QnpCLEVBQUUsQ0FBQ1EsTUFBNUIsQ0FBZCxDQVRPLENBUzJDOztBQUVsRFIsSUFBQUEsRUFBRSxDQUFDMEIsS0FBSCxDQUFTLEtBQUtwQixNQUFkLEVBQ0RxQixFQURDLENBQ0UsR0FERixFQUNNO0FBQUNDLE1BQUFBLFFBQVEsRUFBQztBQUFWLEtBRE4sRUFFRkMsS0FGRTtBQUlBLFFBQUlDLFFBQVEsR0FBQyxLQUFLbEIsSUFBTCxDQUFVa0IsUUFBdkIsQ0FmTyxDQWV5Qjs7QUFDaENBLElBQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsQ0FBWUMsQ0FBWixHQUFjLENBQWQsQ0FoQk8sQ0FnQlM7O0FBQ2hCRCxJQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLENBQVlDLENBQVosR0FBYyxHQUFkO0FBQ0FELElBQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsQ0FBWUMsQ0FBWixHQUFjLEdBQWQ7QUFDQUQsSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixDQUFZRSxNQUFaLEdBQW1CLEtBQW5CLENBbkJPLENBbUJrQjs7QUFHekIsU0FBS2hCLFNBQUwsR0FBZSxJQUFJaEIsRUFBRSxDQUFDaUIsUUFBUCxFQUFmO0FBQ0YsR0ExQ0c7QUE0Q0xZLEVBQUFBLEtBNUNLLG1CQTRDSSxDQUVSLENBOUNJO0FBK0NMSSxFQUFBQSxNQS9DSyxrQkErQ0dDLEVBL0NILEVBK0NPO0FBQ1YsU0FBS2hCLFNBQUwsSUFBZ0IsQ0FBaEI7O0FBQ0EsUUFBRyxLQUFLQSxTQUFMLEdBQWUsR0FBZixJQUFvQixDQUF2QixFQUF5QjtBQUN2QixVQUFJUCxLQUFLLEdBQUMsS0FBS08sU0FBTCxHQUFlLElBQXpCO0FBQ0lQLE1BQUFBLEtBQUssR0FBQyxDQUFDLEdBQUQsR0FBS0EsS0FBSyxHQUFDLEdBQWpCO0FBQ0osVUFBSUcsS0FBSyxHQUFDLEtBQUtxQixTQUFMLENBQWUsS0FBS25CLFNBQXBCLEVBQThCLEtBQUtGLEtBQW5DLENBQVY7QUFDQSxXQUFLc0IsU0FBTCxDQUFldEIsS0FBZixFQUFxQixDQUFDLEdBQXRCLEVBQTBCLEtBQUtFLFNBQS9CLEVBQXlDcUIsSUFBSSxDQUFDQyxNQUFMLEVBQXpDO0FBQ0E7O0FBRUYsU0FBSzNCLEtBQUwsSUFBWSxJQUFaLENBVFUsQ0FTTzs7QUFDakIsU0FBS0wsTUFBTCxDQUFZaUMsQ0FBWixJQUFlLEtBQUs1QixLQUFwQixDQVZVLENBVWdCOztBQUV4QixTQUFLUCxVQUFMLENBQWdCMkIsQ0FBaEIsSUFBbUIsQ0FBbkIsQ0FaUSxDQVlhOztBQUNyQixRQUFHLEtBQUszQixVQUFMLENBQWdCMkIsQ0FBaEIsSUFBbUIsQ0FBQyxJQUF2QixFQUE0QjtBQUN6QixXQUFLM0IsVUFBTCxDQUFnQjJCLENBQWhCLEdBQWtCLENBQWxCO0FBQ0Y7O0FBRUQsUUFBSUQsUUFBUSxHQUFDLEtBQUtsQixJQUFMLENBQVVrQixRQUF2QixDQWpCUSxDQWlCd0I7O0FBQ2hDLFNBQUtVLFFBQUwsQ0FBY1YsUUFBUSxDQUFDLENBQUQsQ0FBdEIsRUFsQlEsQ0FrQm1COztBQUMzQixTQUFLVSxRQUFMLENBQWNWLFFBQVEsQ0FBQyxDQUFELENBQXRCO0FBQ0EsU0FBS1UsUUFBTCxDQUFjVixRQUFRLENBQUMsQ0FBRCxDQUF0Qjs7QUFFQSxRQUFHQSxRQUFRLENBQUMsQ0FBRCxDQUFSLENBQVlDLENBQVosSUFBZSxDQUFDLEdBQW5CLEVBQXVCO0FBQ3JCRCxNQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLENBQVlFLE1BQVosR0FBbUIsSUFBbkI7QUFDRDtBQUlKLEdBM0VJO0FBNEVMVixFQUFBQSxXQTVFSyx5QkE0RVE7QUFDWCxTQUFLWixNQUFMLEdBQVksS0FBWjtBQUNBLFNBQUtDLEtBQUwsR0FBVyxDQUFYO0FBQ0NYLElBQUFBLEVBQUUsQ0FBQzBCLEtBQUgsQ0FBUyxLQUFLcEIsTUFBZCxFQUNIcUIsRUFERyxDQUNBLEdBREEsRUFDSTtBQUFDYyxNQUFBQSxLQUFLLEVBQUM7QUFBUCxLQURKLEVBRUhaLEtBRkc7QUFHRixHQWxGSTtBQW1GTE4sRUFBQUEsU0FuRkssdUJBbUZNO0FBQ1IsU0FBS2IsTUFBTCxHQUFZLElBQVo7QUFDQVYsSUFBQUEsRUFBRSxDQUFDMEIsS0FBSCxDQUFTLEtBQUtwQixNQUFkLEVBQ0NvQyxLQURELENBQ08sR0FEUCxFQUVEZixFQUZDLENBRUUsR0FGRixFQUVNO0FBQUNjLE1BQUFBLEtBQUssRUFBQyxDQUFDO0FBQVIsS0FGTixFQUdGWixLQUhFO0FBSUYsR0F6Rkk7QUE0Rk5XLEVBQUFBLFFBNUZNLG9CQTRGR3BCLElBNUZILEVBNEZRO0FBRVgsUUFBR0EsSUFBSSxDQUFDVyxDQUFMLEdBQU8sQ0FBUCxHQUFTLENBQUMsR0FBYixFQUFpQjtBQUNmWCxNQUFBQSxJQUFJLENBQUNXLENBQUwsR0FBTyxHQUFQO0FBQ0EsVUFBSVksS0FBSyxHQUFDTixJQUFJLENBQUNDLE1BQUwsS0FBYyxFQUFkLEdBQWlCLEVBQTNCO0FBQ0FsQixNQUFBQSxJQUFJLENBQUNtQixDQUFMLEdBQU9JLEtBQVA7QUFDRDs7QUFDRHZCLElBQUFBLElBQUksQ0FBQ1csQ0FBTCxJQUFRLEdBQVI7QUFDRixHQXBHSztBQXFHTkksRUFBQUEsU0FyR00scUJBcUdJUyxVQXJHSixFQXFHZTdCLE1BckdmLEVBcUdzQjtBQUMzQixRQUFJOEIsTUFBTSxHQUFHRCxVQUFVLENBQUNFLEdBQVgsRUFBYjs7QUFDQSxRQUFJRCxNQUFNLElBQUksSUFBZCxFQUFtQjtBQUNuQkEsTUFBQUEsTUFBTSxHQUFHN0MsRUFBRSxDQUFDK0MsV0FBSCxDQUFlaEMsTUFBZixDQUFUO0FBQ0FmLE1BQUFBLEVBQUUsQ0FBQ2dELEdBQUgsQ0FBTyxrQkFBUDtBQUNBOztBQUNESCxJQUFBQSxNQUFNLENBQUNJLE1BQVAsR0FBY2pELEVBQUUsQ0FBQ2tELElBQUgsQ0FBUSxRQUFSLENBQWQ7QUFDQSxXQUFPTCxNQUFQO0FBQ0QsR0E3R087QUErR1RULEVBQUFBLFNBL0dTLHFCQStHQ1MsTUEvR0QsRUErR1FsQyxLQS9HUixFQStHY2lDLFVBL0dkLEVBK0d5QkwsQ0EvR3pCLEVBK0cyQjtBQUNoQ0EsSUFBQUEsQ0FBQyxHQUFFQSxDQUFDLElBQUUsR0FBSCxHQUFTLENBQUMsRUFBVixHQUFlLEVBQWxCO0FBQ0FNLElBQUFBLE1BQU0sQ0FBQ00sUUFBUCxHQUFnQm5ELEVBQUUsQ0FBQ29ELEVBQUgsQ0FBTSxHQUFOLEVBQVViLENBQVYsQ0FBaEI7QUFDQU0sSUFBQUEsTUFBTSxDQUFDcEIsWUFBUCxDQUFvQnpCLEVBQUUsQ0FBQ3FELFNBQXZCLEVBQWtDQyxjQUFsQyxHQUFpRHRELEVBQUUsQ0FBQ29ELEVBQUgsQ0FBTXpDLEtBQU4sRUFBWUEsS0FBWixDQUFqRDtBQUNBaUMsSUFBQUEsVUFBVSxHQUFDQSxVQUFYO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ3BCLFlBQVAsQ0FBb0J6QixFQUFFLENBQUNxRCxTQUF2QixFQUFrQ0UsWUFBbEMsQ0FBK0MsWUFBVztBQUN4RFYsTUFBQUEsTUFBTSxDQUFDVyxjQUFQO0FBQ0FaLE1BQUFBLFVBQVUsQ0FBQ2EsR0FBWCxDQUFlWixNQUFmO0FBQ0FBLE1BQUFBLE1BQU0sQ0FBQ2EsT0FBUCxHQUFlLEdBQWY7QUFDRixLQUpBLEVBSUUsQ0FKRjtBQUtEO0FBekhNLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgYmFja2dyb3VuZDpjYy5Ob2RlLFxyXG4gICAgICBiaXJkaWU6Y2MuTm9kZSxcclxuICAgICAgcGlwdTE6Y2MuU3ByaXRlLFxyXG4gICAgICBwaXB1MjpjYy5TcHJpdGUsXHJcbiAgICAgIGlzSWRsZTp0cnVlLFxyXG4gICAgICBzcGVlZDowLFxyXG4gICAgICBwaXB1OmNjLk5vZGUsXHJcbiAgICAgIGZhaWw6Y2MuTm9kZSxcclxuICAgICAgYXBwbGU6Y2MuUHJlZmFiLFxyXG4gICAgICBhcHBsZVBvb2w6Y2MuTm9kZVBvb2wsXHJcbiAgICAgIHRpbWVDb3VudDowLFxyXG4gICAgfSxcclxuXHJcbiAgIFxyXG5cclxuICAgICBvbkxvYWQgKCkge1xyXG4gICAgIFxyXG4gICAgICBcclxuICAgICAgICB0aGlzLnNwZWVkPTA7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5pc0lkbGU9dHJ1ZTtcclxuICAgICAgICB0aGlzLm5vZGUub24oXCJtb3VzZWRvd25cIix0aGlzLm9uTW91c2VEb3duLHRoaXMpOy8v57uR5a6a6byg5qCH5LqL5Lu2XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwibW91c2V1cFwiLHRoaXMub25Nb3VzZVVwLHRoaXMpOy8v57uR5a6a6byg5qCH5LqL5Lu2XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5iaXJkaWVOTz10aGlzLmJpcmRpZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTsvL+Wwj+m4n+e7hOS7tlxyXG4gICAgICAgICBcclxuICAgICAgICBjYy50d2Vlbih0aGlzLmJpcmRpZSlcclxuICAgICAgLnRvKDAuOCx7cm90YXRpb246NzB9KVxyXG4gICAgIC5zdGFydCgpXHJcblxyXG4gICAgICAgIHZhciBjaGlsZHJlbj10aGlzLnBpcHUuY2hpbGRyZW47Ly/lvpfliLDnrqHlrZDnmoTniLboioLngrlcclxuICAgICAgICBjaGlsZHJlblswXS54PTA7Ly/nrqHlrZDliJ3lp4vkvY3nva5cclxuICAgICAgICBjaGlsZHJlblsxXS54PTM1MDtcclxuICAgICAgICBjaGlsZHJlblsyXS54PTcwMDtcclxuICAgICAgICBjaGlsZHJlblswXS5hY3RpdmU9ZmFsc2U7Ly/nrqHpgZPkuI3lj6/op4FcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgdGhpcy5hcHBsZVBvb2w9bmV3IGNjLk5vZGVQb29sKCk7XHJcbiAgICAgfSwgICAgXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgIHRoaXMudGltZUNvdW50Kz0xO1xyXG4gICAgICBpZih0aGlzLnRpbWVDb3VudCU4MDA9PTApe1xyXG4gICAgICAgIHZhciBzcGVlZD10aGlzLnRpbWVDb3VudC8xMDAwO1xyXG4gICAgICAgICAgICBzcGVlZD0tMjUwK3NwZWVkKjAuMjtcclxuICAgICAgICB2YXIgYXBwbGU9dGhpcy5uZXdPYmplY3QodGhpcy5hcHBsZVBvb2wsdGhpcy5hcHBsZSk7XHJcbiAgICAgICAgdGhpcy5hbGxBY3Rpb24oYXBwbGUsLTIwMCx0aGlzLmFwcGxlUG9vbCxNYXRoLnJhbmRvbSgpKTsgICAgICAgICBcclxuICAgICAgIH1cclxuICAgICAgIFxyXG4gICAgICB0aGlzLnNwZWVkLT0wLjA1Oy8v5bCP6bif55qE6YCf5bqm5pu05pawICAgICAgIFxyXG4gICAgICB0aGlzLmJpcmRpZS55Kz10aGlzLnNwZWVkOy8v5bCP6bif5LiK5LiL56e75YqoXHJcblxyXG4gICAgICAgIHRoaXMuYmFja2dyb3VuZC54LT0xOy8v6IOM5pmv56e75YqoXHJcbiAgICAgICAgaWYodGhpcy5iYWNrZ3JvdW5kLng8PS0xNTAwKXtcclxuICAgICAgICAgICB0aGlzLmJhY2tncm91bmQueD0wOyAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgdmFyIGNoaWxkcmVuPXRoaXMucGlwdS5jaGlsZHJlbjsvL+W+l+WIsOaJgOaciemanOeijeeahOeItuiKgueCuVxyXG4gICAgICAgIHRoaXMucGlwdU1vdmUoY2hpbGRyZW5bMF0pOy8v6Zqc56KN54mp56e75YqoXHJcbiAgICAgICAgdGhpcy5waXB1TW92ZShjaGlsZHJlblsxXSk7ICAgXHJcbiAgICAgICAgdGhpcy5waXB1TW92ZShjaGlsZHJlblsyXSk7ICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYoY2hpbGRyZW5bMF0ueDw9LTUyOSl7XHJcbiAgICAgICAgICBjaGlsZHJlblswXS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIFxyXG4gICAgICAgXHJcbiAgICB9LFxyXG4gICAgb25Nb3VzZURvd24oKXtcclxuICAgICAgdGhpcy5pc0lkbGU9ZmFsc2U7XHJcbiAgICAgIHRoaXMuc3BlZWQ9MztcclxuICAgICAgIGNjLnR3ZWVuKHRoaXMuYmlyZGllKVxyXG4gICAudG8oMC4zLHthbmdsZTo3MH0pXHJcbiAgIC5zdGFydCgpXHJcbiAgICB9LFxyXG4gICAgb25Nb3VzZVVwKCl7XHJcbiAgICAgICB0aGlzLmlzSWRsZT10cnVlO1xyXG4gICAgICAgY2MudHdlZW4odGhpcy5iaXJkaWUpXHJcbiAgICAgICAuZGVsYXkoMC4zKVxyXG4gICAgIC50bygwLjgse2FuZ2xlOi03MH0pXHJcbiAgICAuc3RhcnQoKVxyXG4gICAgfSxcclxuICAgXHJcbiAgIFxyXG4gICBwaXB1TW92ZShub2RlKXtcclxuICAgICAgXHJcbiAgICAgIGlmKG5vZGUueC0xPC01MzApe1xyXG4gICAgICAgIG5vZGUueD01MzA7XHJcbiAgICAgICAgdmFyIHBpcHVZPU1hdGgucmFuZG9tKCkqNTAtMjU7XHJcbiAgICAgICAgbm9kZS55PXBpcHVZO1xyXG4gICAgICB9XHJcbiAgICAgIG5vZGUueC09MS41O1xyXG4gICB9LFxyXG4gICBuZXdPYmplY3Qob2JqZWN0UG9vbCxQcmVmYWIpe1xyXG4gICAgdmFyIG9iamVjdCA9IG9iamVjdFBvb2wuZ2V0KCk7XHJcbiAgICBpZiAob2JqZWN0ID09IG51bGwpe1xyXG4gICAgb2JqZWN0ID0gY2MuaW5zdGFudGlhdGUoUHJlZmFiKTtcclxuICAgIGNjLmxvZyhcImNyZWF0ZSBuZXcgYXBwbGVcIik7XHJcbiAgIH1cclxuICAgb2JqZWN0LnBhcmVudD1jYy5maW5kKFwiQ2FudmFzXCIpO1xyXG4gICByZXR1cm4gb2JqZWN0O1xyXG4gfSxcclxuXHJcbmFsbEFjdGlvbihvYmplY3Qsc3BlZWQsb2JqZWN0UG9vbCx5KXtcclxuICAgIHk9IHk+PTAuNSA/IC0zMCA6IDMwO1xyXG4gICAgb2JqZWN0LnBvc2l0aW9uPWNjLnYyKDUyNSx5KTsgICAgIFxyXG4gICAgb2JqZWN0LmdldENvbXBvbmVudChjYy5SaWdpZEJvZHkpLmxpbmVhclZlbG9jaXR5PWNjLnYyKHNwZWVkLHNwZWVkKTtcclxuICAgIG9iamVjdFBvb2w9b2JqZWN0UG9vbDtcclxuICAgIG9iamVjdC5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgIG9iamVjdC5zdG9wQWxsQWN0aW9ucygpO1xyXG4gICAgICBvYmplY3RQb29sLnB1dChvYmplY3QpO1xyXG4gICAgICBvYmplY3Qub3BhY2l0eT0yNTU7ICAgICAgXHJcbiAgIH0sIDMpO1xyXG4gIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/Scenectroll.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f26cdf8KTpJq6np0/9O/EH4', 'Scenectroll');
// javascript/Scenectroll.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    startbutton: cc.Node,
    bird1: cc.Node,
    bird2: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.startbutton.on("mousedown", this.onMouseDown, this);
  },
  start: function start() {},
  onMouseDown: function onMouseDown() {
    cc.director.loadScene("skinChoose");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcU2NlbmVjdHJvbGwuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFydGJ1dHRvbiIsIk5vZGUiLCJiaXJkMSIsImJpcmQyIiwib25Mb2FkIiwib24iLCJvbk1vdXNlRG93biIsInN0YXJ0IiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNUQyxJQUFBQSxXQUFXLEVBQUNKLEVBQUUsQ0FBQ0ssSUFETjtBQUVUQyxJQUFBQSxLQUFLLEVBQUNOLEVBQUUsQ0FBQ0ssSUFGQTtBQUdURSxJQUFBQSxLQUFLLEVBQUNQLEVBQUUsQ0FBQ0s7QUFIQSxHQUhQO0FBU0w7QUFFQ0csRUFBQUEsTUFYSSxvQkFXTTtBQUNQLFNBQUtKLFdBQUwsQ0FBaUJLLEVBQWpCLENBQW9CLFdBQXBCLEVBQWdDLEtBQUtDLFdBQXJDLEVBQWlELElBQWpEO0FBRUYsR0FkRztBQWdCTEMsRUFBQUEsS0FoQkssbUJBZ0JJLENBRVIsQ0FsQkk7QUFvQkxELEVBQUFBLFdBcEJLLHlCQW9CUTtBQUNUVixJQUFBQSxFQUFFLENBQUNZLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixZQUF0QjtBQUNILEdBdEJJLENBdUJMOztBQXZCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICBzdGFydGJ1dHRvbjpjYy5Ob2RlLFxyXG4gICAgICAgYmlyZDE6Y2MuTm9kZSxcclxuICAgICAgIGJpcmQyOmNjLk5vZGUsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuc3RhcnRidXR0b24ub24oXCJtb3VzZWRvd25cIix0aGlzLm9uTW91c2VEb3duLHRoaXMpO1xyXG4gICAgICAgXHJcbiAgICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuICAgXHJcbiAgICBvbk1vdXNlRG93bigpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcInNraW5DaG9vc2VcIik7XHJcbiAgICB9LFxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/gradeCtrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4ef3dF0IlRDmZJ7UKDcjkOb', 'gradeCtrl');
// javascript/gradeCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    grade: cc.Label,
    count: 0
  },
  onLoad: function onLoad() {
    this.count = 0;
  },
  start: function start() {},
  update: function update(dt) {
    this.count += Math.ceil(dt); //向上取整(0.1--1)

    this.grade.string = this.count;
    Global.overGrade = this.count;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcZ3JhZGVDdHJsLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiZ3JhZGUiLCJMYWJlbCIsImNvdW50Iiwib25Mb2FkIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIk1hdGgiLCJjZWlsIiwic3RyaW5nIiwiR2xvYmFsIiwib3ZlckdyYWRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsS0FBSyxFQUFDSixFQUFFLENBQUNLLEtBREQ7QUFFUkMsSUFBQUEsS0FBSyxFQUFDO0FBRkUsR0FIUDtBQVVMQyxFQUFBQSxNQVZLLG9CQVVLO0FBQ04sU0FBS0QsS0FBTCxHQUFXLENBQVg7QUFFSCxHQWJJO0FBZUxFLEVBQUFBLEtBZkssbUJBZUksQ0FFUixDQWpCSTtBQW1CTEMsRUFBQUEsTUFuQkssa0JBbUJHQyxFQW5CSCxFQW1CTztBQUNSLFNBQUtKLEtBQUwsSUFBWUssSUFBSSxDQUFDQyxJQUFMLENBQVVGLEVBQVYsQ0FBWixDQURRLENBQ2tCOztBQUMxQixTQUFLTixLQUFMLENBQVdTLE1BQVgsR0FBa0IsS0FBS1AsS0FBdkI7QUFDQVEsSUFBQUEsTUFBTSxDQUFDQyxTQUFQLEdBQWlCLEtBQUtULEtBQXRCO0FBQ0g7QUF2QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGdyYWRlOmNjLkxhYmVsLFxyXG4gICAgICAgIGNvdW50OjAsXHJcbiAgICB9LFxyXG5cclxuICAgXHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICB0aGlzLmNvdW50PTA7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmNvdW50Kz1NYXRoLmNlaWwoZHQpOy8v5ZCR5LiK5Y+W5pW0KDAuMS0tMSlcclxuICAgICAgICB0aGlzLmdyYWRlLnN0cmluZz10aGlzLmNvdW50O1xyXG4gICAgICAgIEdsb2JhbC5vdmVyR3JhZGU9dGhpcy5jb3VudDtcclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------
