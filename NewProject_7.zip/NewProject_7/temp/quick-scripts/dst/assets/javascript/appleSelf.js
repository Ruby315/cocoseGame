
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/appleSelf.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd070d3FL2dMEIFSAYI534TA', 'appleSelf');
// javascript/appleSelf.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  start: function start() {},
  update: function update(dt) {},
  onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
    if (otherCollider.node.group == "hidden") {
      var a = this.node.getComponent(cc.RigidBody).linearVelocity.y;
      this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(-200, -a);
      console.log(this.node.getComponent(cc.RigidBody).linearVelocity.y);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcYXBwbGVTZWxmLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInNlbGZDb2xsaWRlciIsIm90aGVyQ29sbGlkZXIiLCJub2RlIiwiZ3JvdXAiLCJhIiwiZ2V0Q29tcG9uZW50IiwiUmlnaWRCb2R5IiwibGluZWFyVmVsb2NpdHkiLCJ5IiwidjIiLCJjb25zb2xlIiwibG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQVNMQyxFQUFBQSxNQVRLLG9CQVNLLENBQUUsQ0FUUDtBQVdMQyxFQUFBQSxLQVhLLG1CQVdJLENBRVIsQ0FiSTtBQWVMQyxFQUFBQSxNQWZLLGtCQWVHQyxFQWZILEVBZU8sQ0FBRSxDQWZUO0FBZ0JMQyxFQUFBQSxjQUFjLEVBQUUsd0JBQVVDLE9BQVYsRUFBbUJDLFlBQW5CLEVBQWlDQyxhQUFqQyxFQUFnRDtBQUM1RCxRQUFHQSxhQUFhLENBQUNDLElBQWQsQ0FBbUJDLEtBQW5CLElBQTBCLFFBQTdCLEVBQXNDO0FBQ2xDLFVBQUlDLENBQUMsR0FBRSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJmLEVBQUUsQ0FBQ2dCLFNBQTFCLEVBQXFDQyxjQUFyQyxDQUFvREMsQ0FBM0Q7QUFDQSxXQUFLTixJQUFMLENBQVVHLFlBQVYsQ0FBdUJmLEVBQUUsQ0FBQ2dCLFNBQTFCLEVBQXFDQyxjQUFyQyxHQUFvRGpCLEVBQUUsQ0FBQ21CLEVBQUgsQ0FBTSxDQUFDLEdBQVAsRUFBVyxDQUFDTCxDQUFaLENBQXBEO0FBQ0FNLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQUtULElBQUwsQ0FBVUcsWUFBVixDQUF1QmYsRUFBRSxDQUFDZ0IsU0FBMUIsRUFBcUNDLGNBQXJDLENBQW9EQyxDQUFoRTtBQUNIO0FBSUo7QUF6QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIFxyXG5cclxuICAgIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7fSxcclxuICAgIG9uQmVnaW5Db250YWN0OiBmdW5jdGlvbiAoY29udGFjdCwgc2VsZkNvbGxpZGVyLCBvdGhlckNvbGxpZGVyKSB7ICAgICAgXHJcbiAgICAgICAgaWYob3RoZXJDb2xsaWRlci5ub2RlLmdyb3VwPT1cImhpZGRlblwiKXtcclxuICAgICAgICAgICAgdmFyIGE9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS5saW5lYXJWZWxvY2l0eS55O1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHk9Y2MudjIoLTIwMCwtYSk7ICAgXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS5saW5lYXJWZWxvY2l0eS55KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIFxyXG4gICAgXHJcbiAgICB9LFxyXG59KTtcclxuIl19