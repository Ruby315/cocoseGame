
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/collion.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f5b8f33mLRBr4KuxCAjyyJK', 'collion');
// javascript/collion.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    audioSource: cc.AudioSource,
    IsBlink: false,
    skin1: cc.SpriteFrame,
    skin2: cc.SpriteFrame
  },
  onLoad: function onLoad() {
    cc.director.getCollisionManager().enabled = true;
    cc.director.getPhysicsManager().enabled = true;

    if (Global.skin == 1) {
      this.node.getComponent(cc.Sprite).spriteFrame = this.skin1;
    } else {
      this.node.getComponent(cc.Sprite).spriteFrame = this.skin2;
    }
  },
  start: function start() {},
  update: function update(dt) {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    var _this = this;

    var numbernode = cc.find("Canvas/life/lifeNumber"); //获取生命值文本信息

    var string = numbernode.getComponent(cc.Label).string;

    if (other.node.group == "block") {
      if (this.IsBlink == false) {
        this.IsBlink = true;
        cc.tween(self.node) //角色触碰障碍物闪烁
        .blink(3, 4).call(function () {
          _this.IsBlink = false;
        }).start();
        this.audioSource.play(); //角色死亡音效

        numbernode.getComponent(cc.Label).string = String(Number(string) - 1);
      }
    }

    if (string <= 1) {
      this.node.active = false; //角色消失（死亡）   

      cc.director.loadScene("gameOver");
    }
  },
  onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
    var numbernode = cc.find("Canvas/life/lifeNumber"); //获取生命值文本信息

    var string = numbernode.getComponent(cc.Label).string;

    if (otherCollider.node.group == "apple") {
      numbernode.getComponent(cc.Label).string = String(Number(string) + 1); //生命值加一

      otherCollider.node.destroy(); //摧毁节点`               
    }

    if (otherCollider.node.group == "floor") {
      this.node.active = false; //角色消失（死亡）   

      this.audioSource.play(); //角色死亡音效

      cc.director.loadScene("gameOver");
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcY29sbGlvbi5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImF1ZGlvU291cmNlIiwiQXVkaW9Tb3VyY2UiLCJJc0JsaW5rIiwic2tpbjEiLCJTcHJpdGVGcmFtZSIsInNraW4yIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJnZXRDb2xsaXNpb25NYW5hZ2VyIiwiZW5hYmxlZCIsImdldFBoeXNpY3NNYW5hZ2VyIiwiR2xvYmFsIiwic2tpbiIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsInN0YXJ0IiwidXBkYXRlIiwiZHQiLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwibnVtYmVybm9kZSIsImZpbmQiLCJzdHJpbmciLCJMYWJlbCIsImdyb3VwIiwidHdlZW4iLCJibGluayIsImNhbGwiLCJwbGF5IiwiU3RyaW5nIiwiTnVtYmVyIiwiYWN0aXZlIiwibG9hZFNjZW5lIiwib25CZWdpbkNvbnRhY3QiLCJjb250YWN0Iiwic2VsZkNvbGxpZGVyIiwib3RoZXJDb2xsaWRlciIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNWQyxJQUFBQSxXQUFXLEVBQUNKLEVBQUUsQ0FBQ0ssV0FETDtBQUVWQyxJQUFBQSxPQUFPLEVBQUMsS0FGRTtBQUdWQyxJQUFBQSxLQUFLLEVBQUNQLEVBQUUsQ0FBQ1EsV0FIQztBQUlWQyxJQUFBQSxLQUFLLEVBQUNULEVBQUUsQ0FBQ1E7QUFKQyxHQUhQO0FBV0xFLEVBQUFBLE1BWEssb0JBV0s7QUFDUlYsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLG1CQUFaLEdBQWtDQyxPQUFsQyxHQUEwQyxJQUExQztBQUNBYixJQUFBQSxFQUFFLENBQUNXLFFBQUgsQ0FBWUcsaUJBQVosR0FBZ0NELE9BQWhDLEdBQTBDLElBQTFDOztBQUNBLFFBQUdFLE1BQU0sQ0FBQ0MsSUFBUCxJQUFhLENBQWhCLEVBQWtCO0FBQ2hCLFdBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QmxCLEVBQUUsQ0FBQ21CLE1BQTFCLEVBQWtDQyxXQUFsQyxHQUE4QyxLQUFLYixLQUFuRDtBQUNELEtBRkQsTUFFSztBQUNILFdBQUtVLElBQUwsQ0FBVUMsWUFBVixDQUF1QmxCLEVBQUUsQ0FBQ21CLE1BQTFCLEVBQWtDQyxXQUFsQyxHQUE4QyxLQUFLWCxLQUFuRDtBQUNEO0FBRUYsR0FwQkk7QUFzQkxZLEVBQUFBLEtBdEJLLG1CQXNCSSxDQUVSLENBeEJJO0FBMEJOQyxFQUFBQSxNQTFCTSxrQkEwQkVDLEVBMUJGLEVBMEJNLENBRVgsQ0E1Qks7QUE2Qk5DLEVBQUFBLGdCQUFnQixFQUFDLDBCQUFTQyxLQUFULEVBQWVDLElBQWYsRUFBb0I7QUFBQTs7QUFFbkMsUUFBS0MsVUFBVSxHQUFHM0IsRUFBRSxDQUFDNEIsSUFBSCxDQUFRLHdCQUFSLENBQWxCLENBRm1DLENBRWlCOztBQUNuRCxRQUFLQyxNQUFNLEdBQUdGLFVBQVUsQ0FBQ1QsWUFBWCxDQUF3QmxCLEVBQUUsQ0FBQzhCLEtBQTNCLEVBQWtDRCxNQUFoRDs7QUFDQSxRQUFHSixLQUFLLENBQUNSLElBQU4sQ0FBV2MsS0FBWCxJQUFrQixPQUFyQixFQUE2QjtBQUMzQixVQUFHLEtBQUt6QixPQUFMLElBQWMsS0FBakIsRUFBdUI7QUFDckIsYUFBS0EsT0FBTCxHQUFhLElBQWI7QUFDQU4sUUFBQUEsRUFBRSxDQUFDZ0MsS0FBSCxDQUFTTixJQUFJLENBQUNULElBQWQsRUFBb0I7QUFBcEIsU0FDQ2dCLEtBREQsQ0FDTyxDQURQLEVBQ1MsQ0FEVCxFQUVDQyxJQUZELENBRU8sWUFBSTtBQUNULFVBQUEsS0FBSSxDQUFDNUIsT0FBTCxHQUFhLEtBQWI7QUFDRCxTQUpELEVBS0NlLEtBTEQ7QUFNQSxhQUFLakIsV0FBTCxDQUFpQitCLElBQWpCLEdBUnFCLENBUUc7O0FBQ3hCUixRQUFBQSxVQUFVLENBQUNULFlBQVgsQ0FBd0JsQixFQUFFLENBQUM4QixLQUEzQixFQUFrQ0QsTUFBbEMsR0FBeUNPLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDUixNQUFELENBQU4sR0FBZSxDQUFoQixDQUEvQztBQUNIO0FBQ0Y7O0FBQ0MsUUFBR0EsTUFBTSxJQUFFLENBQVgsRUFBYTtBQUNYLFdBQUtaLElBQUwsQ0FBVXFCLE1BQVYsR0FBaUIsS0FBakIsQ0FEVyxDQUNZOztBQUN2QnRDLE1BQUFBLEVBQUUsQ0FBQ1csUUFBSCxDQUFZNEIsU0FBWixDQUFzQixVQUF0QjtBQUVEO0FBRUgsR0FwREs7QUFzREpDLEVBQUFBLGNBQWMsRUFBRSx3QkFBVUMsT0FBVixFQUFtQkMsWUFBbkIsRUFBaUNDLGFBQWpDLEVBQWdEO0FBQy9ELFFBQUtoQixVQUFVLEdBQUczQixFQUFFLENBQUM0QixJQUFILENBQVEsd0JBQVIsQ0FBbEIsQ0FEK0QsQ0FDWDs7QUFDcEQsUUFBS0MsTUFBTSxHQUFHRixVQUFVLENBQUNULFlBQVgsQ0FBd0JsQixFQUFFLENBQUM4QixLQUEzQixFQUFrQ0QsTUFBaEQ7O0FBRUEsUUFBR2MsYUFBYSxDQUFDMUIsSUFBZCxDQUFtQmMsS0FBbkIsSUFBMEIsT0FBN0IsRUFBcUM7QUFDakNKLE1BQUFBLFVBQVUsQ0FBQ1QsWUFBWCxDQUF3QmxCLEVBQUUsQ0FBQzhCLEtBQTNCLEVBQWtDRCxNQUFsQyxHQUF5Q08sTUFBTSxDQUFDQyxNQUFNLENBQUNSLE1BQUQsQ0FBTixHQUFlLENBQWhCLENBQS9DLENBRGlDLENBQ2lDOztBQUNsRWMsTUFBQUEsYUFBYSxDQUFDMUIsSUFBZCxDQUFtQjJCLE9BQW5CLEdBRmlDLENBRUo7QUFDaEM7O0FBQ0QsUUFBR0QsYUFBYSxDQUFDMUIsSUFBZCxDQUFtQmMsS0FBbkIsSUFBMEIsT0FBN0IsRUFBcUM7QUFDbkMsV0FBS2QsSUFBTCxDQUFVcUIsTUFBVixHQUFpQixLQUFqQixDQURtQyxDQUNaOztBQUN2QixXQUFLbEMsV0FBTCxDQUFpQitCLElBQWpCLEdBRm1DLENBRVg7O0FBQ3hCbkMsTUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVk0QixTQUFaLENBQXNCLFVBQXRCO0FBQ0Q7QUFJSjtBQXRFTSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgIGF1ZGlvU291cmNlOmNjLkF1ZGlvU291cmNlLFxyXG4gICAgICBJc0JsaW5rOmZhbHNlLFxyXG4gICAgICBza2luMTpjYy5TcHJpdGVGcmFtZSxcclxuICAgICAgc2tpbjI6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICB9LFxyXG5cclxuICAgIFxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpLmVuYWJsZWQ9dHJ1ZTtcclxuICAgICAgY2MuZGlyZWN0b3IuZ2V0UGh5c2ljc01hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcclxuICAgICAgaWYoR2xvYmFsLnNraW49PTEpe1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT10aGlzLnNraW4xO1xyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9dGhpcy5za2luMjtcclxuICAgICAgfVxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICB1cGRhdGUgKGR0KSB7XHJcblxyXG4gICB9LFxyXG4gICBvbkNvbGxpc2lvbkVudGVyOmZ1bmN0aW9uKG90aGVyLHNlbGYpe1xyXG4gICAgXHJcbiAgICAgdmFyICBudW1iZXJub2RlID0gY2MuZmluZChcIkNhbnZhcy9saWZlL2xpZmVOdW1iZXJcIik7Ly/ojrflj5bnlJ/lkb3lgLzmlofmnKzkv6Hmga9cclxuICAgICAgdmFyICBzdHJpbmcgPSBudW1iZXJub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nOyBcclxuICAgICAgaWYob3RoZXIubm9kZS5ncm91cD09XCJibG9ja1wiKXtcclxuICAgICAgICBpZih0aGlzLklzQmxpbms9PWZhbHNlKXtcclxuICAgICAgICAgIHRoaXMuSXNCbGluaz10cnVlO1xyXG4gICAgICAgICAgY2MudHdlZW4oc2VsZi5ub2RlKSAvL+inkuiJsuinpueisOmanOeijeeJqemXqueDgVxyXG4gICAgICAgICAgLmJsaW5rKDMsNCkgICAgXHJcbiAgICAgICAgICAuY2FsbCggKCk9PntcclxuICAgICAgICAgICAgdGhpcy5Jc0JsaW5rPWZhbHNlOyAgICAgICAgICAgXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLnN0YXJ0KClcclxuICAgICAgICAgIHRoaXMuYXVkaW9Tb3VyY2UucGxheSgpOy8v6KeS6Imy5q275Lqh6Z+z5pWIXHJcbiAgICAgICAgICBudW1iZXJub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVN0cmluZyhOdW1iZXIoc3RyaW5nKS0xKTtcclxuICAgICAgfSAgICAgICAgICAgIFxyXG4gICAgfVxyXG4gICAgICBpZihzdHJpbmc8PTEpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmU9ZmFsc2U7Ly/op5LoibLmtojlpLHvvIjmrbvkuqHvvIkgICBcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJnYW1lT3ZlclwiKTtcclxuICAgICAgICBcclxuICAgICAgfVxyXG4gICAgICAgICBcclxuICAgfSxcclxuIFxyXG4gICAgIG9uQmVnaW5Db250YWN0OiBmdW5jdGlvbiAoY29udGFjdCwgc2VsZkNvbGxpZGVyLCBvdGhlckNvbGxpZGVyKSB7XHJcbiAgICAgIHZhciAgbnVtYmVybm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvbGlmZS9saWZlTnVtYmVyXCIpOy8v6I635Y+W55Sf5ZG95YC85paH5pys5L+h5oGvXHJcbiAgICAgIHZhciAgc3RyaW5nID0gbnVtYmVybm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZzsgXHJcbiAgICAgIFxyXG4gICAgICBpZihvdGhlckNvbGxpZGVyLm5vZGUuZ3JvdXA9PVwiYXBwbGVcIil7XHJcbiAgICAgICAgICBudW1iZXJub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVN0cmluZyhOdW1iZXIoc3RyaW5nKSsxKTsvL+eUn+WRveWAvOWKoOS4gFxyXG4gICAgICAgICAgb3RoZXJDb2xsaWRlci5ub2RlLmRlc3Ryb3koKTsvL+aRp+avgeiKgueCuWAgICAgICAgICAgICAgICBcclxuICAgICAgfVxyXG4gICAgICBpZihvdGhlckNvbGxpZGVyLm5vZGUuZ3JvdXA9PVwiZmxvb3JcIil7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZT1mYWxzZTsvL+inkuiJsua2iOWkse+8iOatu+S6oe+8iSAgIFxyXG4gICAgICAgIHRoaXMuYXVkaW9Tb3VyY2UucGxheSgpOy8v6KeS6Imy5q275Lqh6Z+z5pWIXHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiZ2FtZU92ZXJcIik7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgXHJcbiAgXHJcbiAgfSxcclxufSk7XHJcbiJdfQ==