
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/data.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2e22d87g99HA5RAbHq87y5k', 'data');
// javascript/data.js

"use strict";

window.Global = {
  overGrade: 0,
  skin: 0
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcZGF0YS5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJHbG9iYWwiLCJvdmVyR3JhZGUiLCJza2luIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsR0FBZ0I7QUFFWkMsRUFBQUEsU0FBUyxFQUFDLENBRkU7QUFHWkMsRUFBQUEsSUFBSSxFQUFDO0FBSE8sQ0FBaEIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIndpbmRvdy5HbG9iYWwgPSB7XHJcbiAgICAgIFxyXG4gICAgb3ZlckdyYWRlOjAsXHJcbiAgICBza2luOjAsXHJcbn07Il19