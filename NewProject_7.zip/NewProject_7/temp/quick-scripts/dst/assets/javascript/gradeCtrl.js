
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/gradeCtrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4ef3dF0IlRDmZJ7UKDcjkOb', 'gradeCtrl');
// javascript/gradeCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    grade: cc.Label,
    count: 0
  },
  onLoad: function onLoad() {
    this.count = 0;
  },
  start: function start() {},
  update: function update(dt) {
    this.count += Math.ceil(dt); //向上取整(0.1--1)

    this.grade.string = this.count;
    Global.overGrade = this.count;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcZ3JhZGVDdHJsLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiZ3JhZGUiLCJMYWJlbCIsImNvdW50Iiwib25Mb2FkIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIk1hdGgiLCJjZWlsIiwic3RyaW5nIiwiR2xvYmFsIiwib3ZlckdyYWRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsS0FBSyxFQUFDSixFQUFFLENBQUNLLEtBREQ7QUFFUkMsSUFBQUEsS0FBSyxFQUFDO0FBRkUsR0FIUDtBQVVMQyxFQUFBQSxNQVZLLG9CQVVLO0FBQ04sU0FBS0QsS0FBTCxHQUFXLENBQVg7QUFFSCxHQWJJO0FBZUxFLEVBQUFBLEtBZkssbUJBZUksQ0FFUixDQWpCSTtBQW1CTEMsRUFBQUEsTUFuQkssa0JBbUJHQyxFQW5CSCxFQW1CTztBQUNSLFNBQUtKLEtBQUwsSUFBWUssSUFBSSxDQUFDQyxJQUFMLENBQVVGLEVBQVYsQ0FBWixDQURRLENBQ2tCOztBQUMxQixTQUFLTixLQUFMLENBQVdTLE1BQVgsR0FBa0IsS0FBS1AsS0FBdkI7QUFDQVEsSUFBQUEsTUFBTSxDQUFDQyxTQUFQLEdBQWlCLEtBQUtULEtBQXRCO0FBQ0g7QUF2QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGdyYWRlOmNjLkxhYmVsLFxyXG4gICAgICAgIGNvdW50OjAsXHJcbiAgICB9LFxyXG5cclxuICAgXHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICB0aGlzLmNvdW50PTA7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmNvdW50Kz1NYXRoLmNlaWwoZHQpOy8v5ZCR5LiK5Y+W5pW0KDAuMS0tMSlcclxuICAgICAgICB0aGlzLmdyYWRlLnN0cmluZz10aGlzLmNvdW50O1xyXG4gICAgICAgIEdsb2JhbC5vdmVyR3JhZGU9dGhpcy5jb3VudDtcclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=