
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/overGame/contrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b552aN0j8NNUKKLYjky3btk', 'contrl');
// javascript/overGame/contrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    overGrade: cc.Label,
    skin1: cc.SpriteFrame,
    skin2: cc.SpriteFrame,
    animation: cc.Animation
  },
  onLoad: function onLoad() {
    this.overGrade.string = Global.overGrade;
    this.animation = this.node.getComponent(cc.Animation);

    if (Global.skin == 1) {
      cc.find("Canvas/role2").active = false;
    } else {
      cc.find("Canvas/role").active = false;
    }
  },
  returnMenu: function returnMenu() {
    cc.director.loadScene("SceneStart");
  },
  gameReplay: function gameReplay() {
    cc.director.loadScene("SceneEnter");
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcb3ZlckdhbWVcXGNvbnRybC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm92ZXJHcmFkZSIsIkxhYmVsIiwic2tpbjEiLCJTcHJpdGVGcmFtZSIsInNraW4yIiwiYW5pbWF0aW9uIiwiQW5pbWF0aW9uIiwib25Mb2FkIiwic3RyaW5nIiwiR2xvYmFsIiwibm9kZSIsImdldENvbXBvbmVudCIsInNraW4iLCJmaW5kIiwiYWN0aXZlIiwicmV0dXJuTWVudSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwiZ2FtZVJlcGxheSIsInN0YXJ0IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxTQUFTLEVBQUNKLEVBQUUsQ0FBQ0ssS0FETDtBQUVSQyxJQUFBQSxLQUFLLEVBQUNOLEVBQUUsQ0FBQ08sV0FGRDtBQUdSQyxJQUFBQSxLQUFLLEVBQUNSLEVBQUUsQ0FBQ08sV0FIRDtBQUlSRSxJQUFBQSxTQUFTLEVBQUNULEVBQUUsQ0FBQ1U7QUFKTCxHQUhQO0FBWUxDLEVBQUFBLE1BWkssb0JBWUs7QUFDTixTQUFLUCxTQUFMLENBQWVRLE1BQWYsR0FBc0JDLE1BQU0sQ0FBQ1QsU0FBN0I7QUFDQSxTQUFLSyxTQUFMLEdBQWUsS0FBS0ssSUFBTCxDQUFVQyxZQUFWLENBQXVCZixFQUFFLENBQUNVLFNBQTFCLENBQWY7O0FBQ0EsUUFBR0csTUFBTSxDQUFDRyxJQUFQLElBQWEsQ0FBaEIsRUFBa0I7QUFDZmhCLE1BQUFBLEVBQUUsQ0FBQ2lCLElBQUgsQ0FBUSxjQUFSLEVBQXdCQyxNQUF4QixHQUErQixLQUEvQjtBQUVBLEtBSEgsTUFHTztBQUNIbEIsTUFBQUEsRUFBRSxDQUFDaUIsSUFBSCxDQUFRLGFBQVIsRUFBdUJDLE1BQXZCLEdBQThCLEtBQTlCO0FBQ0Q7QUFFTixHQXRCSTtBQXVCTEMsRUFBQUEsVUF2Qkssd0JBdUJPO0FBQ1JuQixJQUFBQSxFQUFFLENBQUNvQixRQUFILENBQVlDLFNBQVosQ0FBc0IsWUFBdEI7QUFDSCxHQXpCSTtBQTBCTEMsRUFBQUEsVUExQkssd0JBMEJPO0FBQ1J0QixJQUFBQSxFQUFFLENBQUNvQixRQUFILENBQVlDLFNBQVosQ0FBc0IsWUFBdEI7QUFDSCxHQTVCSTtBQTZCTEUsRUFBQUEsS0E3QkssbUJBNkJJLENBRVIsQ0EvQkk7QUFpQ0xDLEVBQUFBLE1BakNLLGtCQWlDR0MsRUFqQ0gsRUFpQ08sQ0FBRTtBQWpDVCxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgb3ZlckdyYWRlOmNjLkxhYmVsLFxyXG4gICAgICAgIHNraW4xOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIHNraW4yOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIGFuaW1hdGlvbjpjYy5BbmltYXRpb24sXHJcbiAgICB9LFxyXG5cclxuICBcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMub3ZlckdyYWRlLnN0cmluZz1HbG9iYWwub3ZlckdyYWRlO1xyXG4gICAgICAgIHRoaXMuYW5pbWF0aW9uPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcclxuICAgICAgICBpZihHbG9iYWwuc2tpbj09MSl7XHJcbiAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9yb2xlMlwiKS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcm9sZVwiKS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgcmV0dXJuTWVudSgpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIlNjZW5lU3RhcnRcIik7XHJcbiAgICB9LFxyXG4gICAgZ2FtZVJlcGxheSgpeyAgICAgICBcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJTY2VuZUVudGVyXCIpO1xyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19