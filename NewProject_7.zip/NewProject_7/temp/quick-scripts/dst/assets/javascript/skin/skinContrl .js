
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/javascript/skin/skinContrl .js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3b724xfLvhNk4yUHWB9oyrM', 'skinContrl ');
// javascript/skin/skinContrl .js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  start: function start() {},
  skinChooseOne: function skinChooseOne() {
    Global.skin = 1;
    cc.director.loadScene("SceneEnter");
  },
  skinChooseTow: function skinChooseTow() {
    Global.skin = 2;
    cc.director.loadScene("SceneEnter");
  },
  ruleEnter: function ruleEnter() {
    cc.find("Canvas/rule").active = true;
  },
  ruleReturn: function ruleReturn() {
    cc.find("Canvas/rule").active = false;
  },
  returnMenu: function returnMenu() {
    cc.director.loadScene("SceneStart");
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcamF2YXNjcmlwdFxcc2tpblxcc2tpbkNvbnRybCAuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJzdGFydCIsInNraW5DaG9vc2VPbmUiLCJHbG9iYWwiLCJza2luIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJza2luQ2hvb3NlVG93IiwicnVsZUVudGVyIiwiZmluZCIsImFjdGl2ZSIsInJ1bGVSZXR1cm4iLCJyZXR1cm5NZW51IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBUUxDLEVBQUFBLE1BUkssb0JBUUssQ0FBRSxDQVJQO0FBVUxDLEVBQUFBLEtBVkssbUJBVUksQ0FFUixDQVpJO0FBYUxDLEVBQUFBLGFBYkssMkJBYVU7QUFDWEMsSUFBQUEsTUFBTSxDQUFDQyxJQUFQLEdBQVksQ0FBWjtBQUNEUixJQUFBQSxFQUFFLENBQUNTLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixZQUF0QjtBQUNGLEdBaEJJO0FBaUJMQyxFQUFBQSxhQWpCSywyQkFpQlU7QUFDWEosSUFBQUEsTUFBTSxDQUFDQyxJQUFQLEdBQVksQ0FBWjtBQUNBUixJQUFBQSxFQUFFLENBQUNTLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixZQUF0QjtBQUNGLEdBcEJHO0FBcUJMRSxFQUFBQSxTQXJCSyx1QkFxQk07QUFDVFosSUFBQUEsRUFBRSxDQUFDYSxJQUFILENBQVEsYUFBUixFQUF1QkMsTUFBdkIsR0FBOEIsSUFBOUI7QUFDRCxHQXZCSTtBQXdCTEMsRUFBQUEsVUF4Qkssd0JBd0JPO0FBQ1JmLElBQUFBLEVBQUUsQ0FBQ2EsSUFBSCxDQUFRLGFBQVIsRUFBdUJDLE1BQXZCLEdBQThCLEtBQTlCO0FBQ0QsR0ExQkU7QUEyQkxFLEVBQUFBLFVBM0JLLHdCQTJCTztBQUNWaEIsSUFBQUEsRUFBRSxDQUFDUyxRQUFILENBQVlDLFNBQVosQ0FBc0IsWUFBdEI7QUFDRCxHQTdCSTtBQThCTE8sRUFBQUEsTUE5Qkssa0JBOEJHQyxFQTlCSCxFQThCTyxDQUFFO0FBOUJULENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICBcclxuICAgIH0sXHJcblxyXG4gICBcclxuICAgIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuICAgIHNraW5DaG9vc2VPbmUoKXtcclxuICAgICAgICBHbG9iYWwuc2tpbj0xO1xyXG4gICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiU2NlbmVFbnRlclwiKTtcclxuICAgIH0sXHJcbiAgICBza2luQ2hvb3NlVG93KCl7XHJcbiAgICAgICAgR2xvYmFsLnNraW49MjtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJTY2VuZUVudGVyXCIpO1xyXG4gICAgIH0sXHJcbiAgICBydWxlRW50ZXIoKXtcclxuICAgICAgY2MuZmluZChcIkNhbnZhcy9ydWxlXCIpLmFjdGl2ZT10cnVlO1xyXG4gICAgfSxcclxuICAgIHJ1bGVSZXR1cm4oKXtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3J1bGVcIikuYWN0aXZlPWZhbHNlO1xyXG4gICAgICB9LFxyXG4gICAgcmV0dXJuTWVudSgpe1xyXG4gICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJTY2VuZVN0YXJ0XCIpO1xyXG4gICAgfSxcclxuICAgIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19