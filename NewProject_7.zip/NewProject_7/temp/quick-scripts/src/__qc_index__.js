
require('./assets/javascript/NewScript');
require('./assets/javascript/Scenectroll');
require('./assets/javascript/appleSelf');
require('./assets/javascript/collion');
require('./assets/javascript/data');
require('./assets/javascript/gradeCtrl');
require('./assets/javascript/menuCtrl');
require('./assets/javascript/overGame/contrl');
require('./assets/javascript/skin/skinContrl ');
